# Marketing Content Engine - Comprehensive Platform Audit
**Date:** January 21, 2026  
**Scope:** Full Platform Analysis  
**Focus:** Architecture, Data Integrity, Code Quality, Refactoring Opportunities

---

## 🏗️ ARCHITECTURE & DATA MODEL ISSUES

### 1. Duplicate/Overlapping Data Structures

#### 🔴 CRITICAL: Content Item Status Confusion

**Problem:** The `content_items` table serves MULTIPLE incompatible purposes:

```typescript
// From conversation history - content_items is used for:
1. Template storage (status = 'source')
2. In-review content (status = 'in_review')  
3. Approved content (status = 'approved')
4. Scheduled content (status = 'scheduled', has scheduled_at)
5. Published content (status = 'published')
```

**Why This Is Bad:**
- Mixing templates with actual content violates Single Responsibility Principle
- Queries need `WHERE status != 'source'` everywhere to exclude templates
- Status transitions are unclear (can you go from 'in_review' to 'scheduled' directly?)
- No audit trail of status changes

**Evidence from Code:**
```sql
-- From conversation logs:
SELECT * FROM content_items 
WHERE deleted_at IS NULL AND status != 'source'  -- Must exclude templates
```

**Recommended Fix:**
```sql
-- Create separate table for templates
CREATE TABLE content_templates (
  id UUID PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT,
  template_type TEXT,
  variables JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Keep content_items for actual content only
CREATE TABLE content_items (
  id UUID PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT,
  status content_status_enum NOT NULL,  -- 'draft', 'in_review', 'approved', 'scheduled', 'published'
  template_id UUID REFERENCES content_templates(id),
  -- ...
);

-- Add audit trail
CREATE TABLE content_status_history (
  id UUID PRIMARY KEY,
  content_item_id UUID REFERENCES content_items(id),
  from_status content_status_enum,
  to_status content_status_enum,
  changed_by UUID REFERENCES profiles(id),
  changed_at TIMESTAMP DEFAULT NOW(),
  reason TEXT
);
```

---

#### 🟡 MODERATE: Queue Items vs Content Items Overlap

**Problem:** `queue_items` and `content_items` have overlapping data:

```typescript
// queue_items schema (inferred):
{
  id: string,
  title: string,              // ❌ Duplicate from content_items
  content: text,              // ❌ Duplicate from content_items
  content_item_id: string,    // FK to content_items
  queue_id: string,
  scheduled_at: timestamp,    // ❌ Also on content_items!
  content_type: text          // ❌ Should come from content_items
}

// content_items already has:
{
  id: string,
  title: string,              // 🔄 Same as queue_items.title
  content: text,              // 🔄 Same as queue_items.content
  scheduled_at: timestamp,    // 🔄 Same as queue_items.scheduled_at
  content_type: text          // 🔄 Should be source of truth
}
```

**Issues:**
- Data duplication means updates need to happen in two places
- `scheduled_at` exists on BOTH tables - which is source of truth?
- If content is edited in content_items, queue_items becomes stale
- No clear ownership of fields

**From Conversation:**
```typescript
// When scheduling, the code:
1. Updates queue_items.scheduled_at = datetime
2. Then ALSO updates content_items.scheduled_at = datetime
3. Then DELETES the queue_item
```

**Recommended Fix:**
```sql
-- queue_items should be LIGHTWEIGHT - just a join table
CREATE TABLE queue_items (
  id UUID PRIMARY KEY,
  content_item_id UUID REFERENCES content_items(id) NOT NULL,
  queue_id UUID REFERENCES publishing_queues(id) NOT NULL,
  position INTEGER,  -- For manual ordering
  added_at TIMESTAMP DEFAULT NOW(),
  added_by UUID REFERENCES profiles(id),
  -- NO title, content, or scheduled_at here!
  UNIQUE(content_item_id, queue_id)  -- Can't add same item to queue twice
);

-- All data stays on content_items
-- To get queue with content: JOIN content_items
```

---

#### 🟡 MODERATE: Podcast Data Chain Too Long

**Problem:** 3-hop relationship to get episode info:

```
content_items.source_content_id 
  → content_packs.id
    → content_packs.source_content_id
      → podcast_episodes.id
        → podcast_episodes.release_date
```

**Why This Is Bad:**
- Complex joins for simple queries
- Performance hit (3 joins to get release date)
- Fragile - any missing link breaks the chain
- Hard to maintain referential integrity

**From Conversation:**
```typescript
// To check podcast release date:
async function getContentPodcastContext(contentItemId) {
  // Step 1: Get content_pack_id
  const contentItem = await supabase
    .from('content_items')
    .select('source_content_id')
    .eq('id', contentItemId)
    .single();
    
  // Step 2: Get podcast_episode_id  
  const contentPack = await supabase
    .from('content_packs')
    .select('source_content_id')
    .eq('id', contentItem.source_content_id)
    .single();
    
  // Step 3: Get release_date
  const episode = await supabase
    .from('podcast_episodes')
    .select('release_date')
    .eq('id', contentPack.source_content_id)
    .single();
}
```

**Recommended Fix:**
```sql
-- Option 1: Denormalize episode_id directly on content_items
ALTER TABLE content_items 
ADD COLUMN podcast_episode_id UUID REFERENCES podcast_episodes(id);

-- Option 2: Create a view for easier querying
CREATE VIEW content_with_episode AS
SELECT 
  ci.*,
  cp.source_content_id as episode_id,
  pe.release_date as episode_release_date,
  pe.episode_title
FROM content_items ci
LEFT JOIN content_packs cp ON ci.source_content_id = cp.id
LEFT JOIN podcast_episodes pe ON cp.source_content_id = pe.id;
```

---

### 2. Hardcoded Values Throughout Codebase

#### 🔴 CRITICAL: Company IDs Hardcoded

**Evidence from Conversation:**
```typescript
// Multiple places in logs:
companyId: "9d6c0ee1-4c3d-477d-8070-1a9d822cb19a"  // Captarget
companyId: "38cfc492-f2dc-4c39-9b99-2310d24309e1"  // SourceCo

// Likely in code somewhere:
const SOURCECO_COMPANY_ID = "38cfc492-f2dc-4c39-9b99-2310d24309e1";
```

**Where This Causes Problems:**
- Can't easily add new companies
- Tests need to mock these specific UUIDs
- Deployment to staging/prod needs UUID mapping
- Migration scripts break if UUIDs don't match

**Recommended Fix:**
```typescript
// Instead of hardcoded UUIDs, use slugs:
const company = await supabase
  .from('companies')
  .select('*')
  .eq('slug', 'sourceco')  // or 'captarget'
  .single();

// Or use environment-based config:
const COMPANY_MAPPING = {
  production: {
    sourceco: "38cfc492-f2dc-4c39-9b99-2310d24309e1",
    captarget: "9d6c0ee1-4c3d-477d-8070-1a9d822cb19a"
  },
  staging: {
    sourceco: "staging-sourceco-uuid",
    captarget: "staging-captarget-uuid"
  }
}[ENV];
```

---

#### 🔴 CRITICAL: Default Settings Hardcoded in Multiple Places

**Problem:** Default AI posting settings are defined in at least 3 different places:

**Place 1: Database Migration**
```sql
ALTER TABLE ai_posting_settings 
ADD COLUMN min_hours_between_any_posts INTEGER DEFAULT 4,
ADD COLUMN carousel_after_carousel_hours INTEGER DEFAULT 24;
```

**Place 2: Edge Function Constants**
```typescript
// supabase/functions/ai-schedule-assistant/lib/constants.ts
export const DEFAULT_SETTINGS = {
  min_hours_between_any_posts: 4,
  carousel_after_carousel_hours: 24,
  video_after_video_hours: 24,
  poll_cooldown_hours: 72,
};
```

**Place 3: Frontend Hook**
```typescript
// src/hooks/useAIPostingSettings.tsx
const defaultSettings = {
  tom_target_posts_per_day: 2,
  sourceco_posts_per_week_min: 3,
  sourceco_posts_per_week_max: 5,
  // ... more defaults
};
```

**Why This Is Bad:**
- If you update DEFAULT in migration, you must also update constants.ts AND hook
- Easy to have mismatched defaults (DB says 4, frontend shows 6)
- No single source of truth

**Evidence:**
```typescript
// From conversation - AI Posting Settings table is EMPTY
SELECT * FROM ai_posting_settings LIMIT 1
Result: []

// This means the edge function falls back to hardcoded defaults
// But which defaults? The DB schema defaults or constants.ts?
```

**Recommended Fix:**
```typescript
// Create a shared constants file used by DB, frontend, and backend
// packages/shared/src/constants/ai-posting-defaults.ts
export const AI_POSTING_DEFAULTS = {
  tom_target_posts_per_day: 2,
  allow_second_post_tom: true,
  min_hours_between_tom_posts: 6,
  sourceco_posts_per_week_min: 3,
  sourceco_posts_per_week_max: 5,
  captarget_posts_per_week_min: 3,
  captarget_posts_per_week_max: 5,
  min_hours_between_any_posts: 4,
  carousel_after_carousel_hours: 24,
  video_after_video_hours: 24,
  poll_cooldown_hours: 72,
  cross_account_same_idea_hours: 36,
  weekend_posting_allowed: false,
  default_timezone: 'America/Chicago',
} as const;

// Use in migration:
// INSERT INTO ai_posting_settings (company_id, settings)
// VALUES (company_id, '${JSON.stringify(AI_POSTING_DEFAULTS)}');

// Use in edge function:
// const settings = dbSettings || AI_POSTING_DEFAULTS;

// Use in frontend:
// const [settings, setSettings] = useState(AI_POSTING_DEFAULTS);
```

---

#### 🟡 MODERATE: Magic Numbers Throughout Code

**Examples from Conversation:**

```typescript
// Time slot definitions hardcoded:
const TIME_SLOT_TIERS = {
  TIER_1: [
    { dayOfWeek: 2, hours: [9, 10] },  // ❌ Why Tuesday? Why 9-10?
    { dayOfWeek: 3, hours: [9, 10] },  // ❌ Magic numbers
  ]
};

// Conversation history hardcoded:
const conversationHistory = messages.slice(-10);  // ❌ Why 10?

// Distribution window hardcoded:
distributionWindowEnd.setDate(distributionWindowEnd.getDate() + 10);  // ❌ Why 10 days?

// Pre-announcement window hardcoded:
earliestPreAnnounce.setDate(earliestPreAnnounce.getDate() - 7);  // ❌ Why 7 days?
```

**Recommended Fix:**
```typescript
// Create named constants with documentation
export const SCHEDULING_CONSTANTS = {
  /** Maximum conversation messages to send to AI for context */
  MAX_CONVERSATION_HISTORY: 10,
  
  /** Days to distribute podcast content after release */
  PODCAST_DISTRIBUTION_WINDOW_DAYS: 10,
  
  /** Days before episode release to allow pre-announcements */
  PODCAST_PRE_ANNOUNCEMENT_DAYS: 7,
  
  /** Optimal engagement days (Tuesday = 2, Wednesday = 3) */
  OPTIMAL_DAYS: [2, 3],
  
  /** Optimal engagement hours */
  OPTIMAL_HOURS: [9, 10, 14],
} as const;
```

---

#### 🟡 MODERATE: Timezone Defaults Inconsistent

**Evidence:**
```typescript
// Database migration says:
ALTER TABLE ai_posting_settings 
ADD COLUMN default_timezone TEXT DEFAULT 'America/Chicago';

// But constants.ts says:
export const DEFAULT_TIMEZONE = 'America/New_York';

// And conversation history mentions Chicago:
// "User's location: Chicago, Illinois, US"
```

**Impact:**
- Posts scheduled at wrong time
- User confusion about when content goes live
- Daylight savings issues if wrong timezone

**Recommended Fix:**
```typescript
// Use user's actual location from company profile
CREATE TABLE companies (
  id UUID PRIMARY KEY,
  name TEXT,
  timezone TEXT NOT NULL DEFAULT 'America/Chicago',
  -- Store timezone with company, not in ai_posting_settings
);

// Then in code:
const company = await getCompany(companyId);
const timezone = company.timezone;  // Always use company's timezone
```

---

### 3. Calculations Done Multiple Ways

#### 🔴 CRITICAL: Weekly Post Count Calculated Differently

**Method 1: In AI Scheduler Edge Function**
```typescript
// From distributor.ts (assumed implementation):
function getWeeklyLimits(settings: AIPostingSettings) {
  return {
    ceo_linkedin: { min: 3, max: 10 },  // ❌ Hardcoded
    sourceco_linkedin: { 
      min: settings.sourceco_posts_per_week_min, 
      max: settings.sourceco_posts_per_week_max 
    },
  };
}
```

**Method 2: In System Prompt**
```typescript
// From conversation history - system prompt includes:
`
CEO: 7-14 posts/week (${settings.tom_target_posts_per_day * 7} based on daily target)
SourceCo: ${settings.sourceco_posts_per_week_min}-${settings.sourceco_posts_per_week_max}
`
```

**Method 3: In Frontend Dashboard (assumed)**
```typescript
// Likely in Analytics or Dashboard:
const weeklyCount = scheduledPosts.filter(post => 
  isThisWeek(post.scheduled_at) && post.target_account === 'ceo'
).length;

// Different week calculation?
// Does it use ISO week, calendar week, or Mon-Sun?
```

**Issues:**
- Different week definitions (Sun-Sat vs Mon-Fri vs ISO week)
- CEO limit calculated as `daily * 7` in one place, hardcoded in another
- If business rules change, must update multiple places

**Recommended Fix:**
```typescript
// Single source of truth utility
export class ScheduleCalculator {
  constructor(private settings: AIPostingSettings) {}
  
  getWeeklyLimit(account: string): { min: number; max: number } {
    switch (account) {
      case 'ceo_linkedin':
        // CEO has no strict weekly max, just daily * 7
        return {
          min: this.settings.tom_target_posts_per_day * 5, // Weekdays
          max: this.settings.tom_target_posts_per_day * 7  // All days
        };
      case 'sourceco_linkedin':
        return {
          min: this.settings.sourceco_posts_per_week_min,
          max: this.settings.sourceco_posts_per_week_max
        };
      case 'captarget_linkedin':
        return {
          min: this.settings.captarget_posts_per_week_min,
          max: this.settings.captarget_posts_per_week_max
        };
      default:
        throw new Error(`Unknown account: ${account}`);
    }
  }
  
  getWeekBounds(date: Date): { start: Date; end: Date } {
    // ISO week (Mon-Sun) - single definition used everywhere
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(date.setDate(diff));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    return { start: monday, end: sunday };
  }
}
```

---

#### 🟡 MODERATE: Date/Time Formatting Inconsistent

**Evidence:**
```typescript
// Method 1: toISOString()
const scheduledAt = scheduledDate.toISOString();

// Method 2: toLocaleString() with timezone
const localInTz = new Date(utcGuess.toLocaleString('en-US', { timeZone: timezone }));

// Method 3: Manual string building
const dateStr = currentDate.toISOString().split('T')[0]; // YYYY-MM-DD

// Method 4: formatDateInTimezone utility (exists but not always used)
formatDateInTimezone(date, timezone)
```

**Issues:**
- Some places use ISO strings, others use locale strings
- Timezone handling differs between functions
- Easy to introduce bugs when converting between formats

**Recommended Fix:**
```typescript
// Create centralized date utilities
export class DateTimeUtil {
  constructor(private timezone: string = 'America/Chicago') {}
  
  toISO(date: Date): string {
    return date.toISOString();
  }
  
  toLocalISO(date: Date): string {
    // Returns "2026-01-20" in the specified timezone
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: this.timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(date);
  }
  
  toLocalDateTime(date: Date): string {
    // Returns "2026-01-20 09:00:00" in the specified timezone
    return new Intl.DateTimeFormat('en-US', {
      timeZone: this.timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).format(date).replace(',', '');
  }
  
  parseLocalTime(dateStr: string, hours: number, minutes: number): Date {
    // Consistent local → UTC conversion
    // Use this everywhere instead of multiple implementations
  }
}
```

---

### 4. Data Integrity Issues

#### 🔴 CRITICAL: No Foreign Key Constraints Visible

**From Conversation:**
```typescript
// These relationships are ASSUMED but not enforced:
content_items.source_content_id → content_packs.id  // ❓ FK exists?
content_packs.source_content_id → podcast_episodes.id  // ❓ FK exists?
queue_items.content_item_id → content_items.id  // ❓ FK exists?
queue_items.queue_id → publishing_queues.id  // ❓ FK exists?
content_items.owner_id → profiles.id  // ❓ FK exists?
```

**Why This Matters:**
- Without FK constraints, you can have orphaned records
- `content_items` pointing to deleted `content_packs`
- `queue_items` pointing to deleted `content_items`
- No cascade delete behavior defined

**Recommended Fix:**
```sql
-- Add foreign key constraints with proper cascade behavior
ALTER TABLE content_items
ADD CONSTRAINT fk_content_pack 
FOREIGN KEY (source_content_id) 
REFERENCES content_packs(id) 
ON DELETE SET NULL;  -- Or CASCADE if content should be deleted

ALTER TABLE queue_items
ADD CONSTRAINT fk_content_item
FOREIGN KEY (content_item_id)
REFERENCES content_items(id)
ON DELETE CASCADE;  -- If content deleted, remove from queue

ALTER TABLE content_items
ADD CONSTRAINT fk_owner
FOREIGN KEY (owner_id)
REFERENCES profiles(id)
ON DELETE SET NULL;  -- Keep content if user deleted
```

---

#### 🟡 MODERATE: Soft Delete Inconsistency

**From Conversation:**
```sql
-- First, soft delete duplicates:
UPDATE content_items SET deleted_at = NOW()
WHERE id IN (SELECT id FROM duplicates WHERE rn > 1)

-- Then later, user requests hard delete:
DELETE FROM content_items WHERE deleted_at IS NOT NULL
```

**Issues:**
- Sometimes soft delete is used, sometimes hard delete
- No consistent policy
- `deleted_at IS NULL` filters scattered throughout queries
- Some queries might forget to filter deleted items

**Recommended Fix:**
```sql
-- Pick one strategy and stick with it:

-- OPTION 1: Always soft delete + create views
CREATE VIEW active_content_items AS
SELECT * FROM content_items WHERE deleted_at IS NULL;

-- Then queries use the view instead of table directly
SELECT * FROM active_content_items;

-- OPTION 2: Use RLS (Row Level Security) to hide deleted items
CREATE POLICY hide_deleted_content ON content_items
FOR SELECT
USING (deleted_at IS NULL OR current_user_is_admin());
```

---

#### 🟡 MODERATE: No Uniqueness Constraints

**Missing Constraints:**
```sql
-- Can add same content to queue multiple times
-- No constraint on queue_items(content_item_id, queue_id)

-- Can create duplicate content_packs for same episode
-- No constraint on content_packs(source_content_id, pack_type)

-- Can schedule same content twice
-- No constraint preventing double-scheduling
```

**Evidence:**
From conversation: *"I soft-deleted 7 duplicate content items"*  
This happened because there's no constraint preventing duplicates!

**Recommended Fix:**
```sql
-- Add uniqueness constraints where needed
ALTER TABLE queue_items
ADD CONSTRAINT unique_content_in_queue 
UNIQUE (content_item_id, queue_id);

ALTER TABLE content_packs
ADD CONSTRAINT unique_pack_per_episode
UNIQUE (source_content_id, pack_type);

-- For scheduled content, could use a partial unique index:
CREATE UNIQUE INDEX unique_scheduled_content 
ON content_items (target_account, scheduled_at)
WHERE status = 'scheduled' AND deleted_at IS NULL;
-- This prevents scheduling two posts at exact same time on same account
```

---

## 🎨 FRONTEND ISSUES

### 5. React Query Cache Management Problems

#### 🔴 CRITICAL: Stale Data + Optimistic Updates = Race Conditions

**From Conversation:**
```typescript
// Problem flow:
1. User sends "schedule posts" 
   → Saved to DB 
   → Cache invalidated
2. AI responds with preview 
   → Saved to DB 
   → Cache invalidated
3. User immediately sends "confirm"
   → Reads from React Query cache
   → Cache hasn't refetched yet!
   → Conversation history is missing the preview message

// Attempted fix with optimistic updates:
queryClient.setQueryData<ChatMessage[]>(
  ['queue-chat-messages', companyId],
  (old = []) => [...old, newMessage]
);
```

**Issues:**
- Optimistic updates + async DB saves = potential mismatches
- Multiple invalidations in quick succession cause race conditions
- No loading states between invalidate → refetch

**Better Approach:**
```typescript
// Option 1: Wait for refetch before allowing next action
const sendMessage = async (message: string) => {
  // Save to DB
  await saveToDB(message);
  
  // Invalidate and WAIT for refetch
  await queryClient.invalidateQueries(['queue-chat-messages']);
  await queryClient.refetchQueries(['queue-chat-messages']);
  
  // Now safe to send next message
  setIsTyping(false);
};

// Option 2: Use mutations properly
const mutation = useMutation({
  mutationFn: sendMessage,
  onSuccess: () => {
    queryClient.invalidateQueries(['queue-chat-messages']);
  },
  onSettled: () => {
    // Only allow next message after settled
    setCanSendMessage(true);
  }
});
```

---

#### 🟡 MODERATE: Duplicate Items in UI

**From Conversation:**
```typescript
// Pipeline showing 17 items when database has only 10
// Same items appearing twice in UI

// Root cause: React Query cache merging old + new results
// Fix was client-side deduplication:
const uniqueItems = Array.from(
  new Map(mappedData.map(item => [item.id, item])).values()
);
```

**Why This Happened:**
- React Query default behavior can merge stale + fresh data during refetch
- No `staleTime` or `gcTime` configuration
- Cache not being cleared properly

**Better Fix:**
```typescript
const { data: contentItems = [] } = useQuery({
  queryKey: ['content-items', companyId],  // ✅ Include companyId in key
  queryFn: fetchContentItems,
  staleTime: 0,           // Data is stale immediately
  gcTime: 1000 * 60 * 5,  // Garbage collect after 5 min
  refetchOnMount: true,
  refetchOnWindowFocus: false,  // Prevent double-fetch on tab switch
  // And yes, still deduplicate just in case:
  select: (data) => Array.from(
    new Map(data.map(item => [item.id, item])).values()
  )
});
```

---

#### 🟡 MODERATE: Global State vs Server State Confusion

**Observed Pattern:**
```typescript
// Some data is in React Query (server state):
const { data: contentItems } = useQuery(['content-items']);

// Other data is in React state (client state):
const [selectedItems, setSelectedItems] = useState([]);

// Some data is in BOTH:
const { data: settings } = useQuery(['ai-posting-settings']);
const [localSettings, setLocalSettings] = useState(settings);  // ❌ Duplication
```

**Issues:**
- Unclear which is source of truth
- Settings in React Query + React state can get out of sync
- Form edits might overwrite unsaved changes from other tabs

**Recommended Pattern:**
```typescript
// Server state (what's in DB) → React Query
const { data: settings } = useQuery(['ai-posting-settings']);

// Client state (form edits not yet saved) → React state
const [formData, setFormData] = useState(settings);

// Sync when server data changes
useEffect(() => {
  setFormData(settings);
}, [settings]);

// Save button commits client state to server
const handleSave = async () => {
  await saveMutation.mutateAsync(formData);
  // React Query auto-refetches and syncs formData via useEffect
};
```

---

### 6. Component Architecture Issues

#### 🟡 MODERATE: Missing Error Boundaries

**No Evidence of Error Boundaries in Conversation**

**Why This Matters:**
- If any component crashes, entire app white-screens
- User loses all work
- No graceful degradation

**Recommended Fix:**
```typescript
// Add error boundaries at key levels:
<ErrorBoundary fallback={<DashboardError />}>
  <Dashboard />
</ErrorBoundary>

<ErrorBoundary fallback={<div>Pipeline failed to load</div>}>
  <Pipeline />
</ErrorBoundary>

// With logging:
class ErrorBoundary extends React.Component {
  componentDidCatch(error, errorInfo) {
    // Log to Sentry or similar
    logError(error, errorInfo);
  }
}
```

---

#### 🟡 MODERATE: Workspace Filtering Not Universal

**From Conversation:**
```typescript
const WORKSPACE_ENABLED_ROUTES = [
  '/dashboard',
  '/assets',
  '/audiences',
  '/settings/audiences',
  '/queues',
  '/pipeline',  // Added during fixes
];

// But /calendar is missing!
// So switching workspace doesn't filter calendar
```

**Issues:**
- Inconsistent behavior across pages
- User switches to Captarget → still sees SourceCo calendar
- Confusing UX

**Recommended Fix:**
```typescript
// Make workspace filtering the DEFAULT, not opt-in
const NON_WORKSPACE_ROUTES = [
  '/login',
  '/signup',
  '/settings/profile',  // Personal settings
  '/settings/billing',  // Account-wide
];

// All other routes auto-filter by workspace
const shouldFilterByWorkspace = (path: string) => {
  return !NON_WORKSPACE_ROUTES.includes(path);
};
```

---

## ⚙️ BACKEND ISSUES

### 7. Edge Function Problems

#### 🟡 MODERATE: Edge Function Network Restrictions Too Strict

**From System Prompt:**
```
Allowed Domains: api.anthropic.com, archive.ubuntu.com, crates.io, 
files.pythonhosted.org, github.com, index.crates.io, npmjs.com, 
npmjs.org, pypi.org, pythonhosted.org, registry.npmjs.org, 
registry.yarnpkg.com, security.ubuntu.com, static.crates.io, 
www.npmjs.com, www.npmjs.org, yarnpkg.com
```

**Missing:**
- LinkedIn API (if you ever need to publish directly)
- Any webhook receivers
- Any third-party integrations (Zapier, Make.com, etc.)

**Recommended:**
Review if edge functions need to call external APIs and update allowed domains accordingly.

---

#### 🟡 MODERATE: No Rate Limiting Visible

**From Conversation:**
- Edge functions can be called repeatedly
- No mention of rate limiting in queue chat
- AI could be spammed with requests

**Recommended Fix:**
```typescript
// Add rate limiting to edge functions
import { rateLimit } from '@upstash/ratelimit';

const limiter = rateLimit({
  redis: REDIS_CLIENT,
  limiter: rateLimit.slidingWindow(10, '1 m'),  // 10 requests per minute
});

export async function handler(req: Request) {
  const { success } = await limiter.limit(req.headers.get('x-user-id'));
  
  if (!success) {
    return new Response('Too many requests', { status: 429 });
  }
  
  // ... rest of handler
}
```

---

### 8. Database Query Patterns

#### 🟡 MODERATE: N+1 Query Problem Likely

**Suspected Pattern:**
```typescript
// Get all content items
const contentItems = await supabase
  .from('content_items')
  .select('*');

// Then for each item, get owner name:
for (const item of contentItems) {
  const { data: profile } = await supabase
    .from('profiles')
    .select('name')
    .eq('id', item.owner_id)
    .single();
  
  item.owner_name = profile.name;  // ❌ N+1 queries!
}
```

**Better Approach:**
```typescript
// Single query with join
const contentItems = await supabase
  .from('content_items')
  .select(`
    *,
    owner:profiles(name)
  `);

// Or even better, use a view:
CREATE VIEW content_items_with_owner AS
SELECT 
  ci.*,
  p.name as owner_name
FROM content_items ci
LEFT JOIN profiles p ON ci.owner_id = p.id;
```

---

#### 🟡 MODERATE: No Database Indexes Mentioned

**From Conversation:**
- Lots of queries on `scheduled_at`, `status`, `company_id`
- No mention of indexes

**Critical Indexes Needed:**
```sql
-- For scheduling queries
CREATE INDEX idx_content_scheduled 
ON content_items(scheduled_at, status) 
WHERE deleted_at IS NULL;

-- For company filtering
CREATE INDEX idx_content_company 
ON content_items(company_id) 
WHERE deleted_at IS NULL;

-- For queue operations
CREATE INDEX idx_queue_items_content 
ON queue_items(content_item_id);

-- For podcast content lookups
CREATE INDEX idx_content_source 
ON content_items(source_content_id);

-- For status filtering (common query)
CREATE INDEX idx_content_status 
ON content_items(status) 
WHERE deleted_at IS NULL;
```

---

## 🔧 REFACTORING OPPORTUNITIES

### 9. Shared Logic That Could Be Extracted

#### 🟢 OPPORTUNITY: Date/Time Utilities

**Current State:** Date handling scattered throughout:
- `createDateInTimezone` in edge function
- `formatDateInTimezone` somewhere else
- Manual date math in multiple places

**Recommended:**
```typescript
// packages/shared/src/utils/datetime.ts
export class DateTimeUtils {
  // All date operations centralized
  static toLocalTime(utc: Date, timezone: string): Date
  static toUTC(local: Date, timezone: string): Date
  static getWeekBounds(date: Date): { start: Date; end: Date }
  static getMonthBounds(date: Date): { start: Date; end: Date }
  static formatForDisplay(date: Date, timezone: string): string
  static parseScheduleTime(dateStr: string, time: string, timezone: string): Date
}
```

---

#### 🟢 OPPORTUNITY: Content Validation Logic

**Current State:**
- Podcast release validation in edge function
- Content similarity checks in edge function
- Probably more validation in frontend

**Recommended:**
```typescript
// packages/shared/src/validators/content-validators.ts
export class ContentValidators {
  static validatePodcastScheduling(
    content: ContentItem,
    scheduledDate: Date
  ): ValidationResult
  
  static validateContentSimilarity(
    newContent: ContentItem,
    existingContent: ContentItem[]
  ): ValidationResult
  
  static validateWeeklyCapacity(
    account: string,
    week: { start: Date; end: Date },
    existingCount: number,
    settings: AIPostingSettings
  ): ValidationResult
}

// Use in both frontend (client-side validation) AND backend (enforcement)
```

---

#### 🟢 OPPORTUNITY: Schedule Calculation Logic

**Current State:**
- Weekly limits calculated in edge function
- Probably also calculated in frontend dashboards/analytics
- Different implementations

**Recommended:**
```typescript
// packages/shared/src/services/schedule-calculator.ts
export class ScheduleCalculator {
  constructor(private settings: AIPostingSettings) {}
  
  getWeeklyLimit(account: string): { min: number; max: number }
  getDailyLimit(account: string, date: Date): number
  calculateRemainingCapacity(account: string, week: WeekBounds): number
  getOptimalSlots(date: Date, account: string): TimeSlot[]
  validateSchedule(items: ScheduleItem[]): ScheduleValidation
}

// Used by:
// - Edge function for actual scheduling
// - Frontend for preview/capacity display
// - Analytics for reporting
```

---

### 10. Type Safety Improvements

#### 🟡 MODERATE: Loose TypeScript Types

**Observed:**
```typescript
// From conversation, types are inferred or using 'any':
const settings: any = await getSettings();  // ❌
const queue: any = queues.find(...);  // ❌
```

**Recommended:**
```typescript
// Create strict types for everything
// packages/shared/src/types/index.ts

export interface Company {
  id: string;
  name: string;
  slug: string;
  timezone: string;
  created_at: string;
}

export interface ContentItem {
  id: string;
  title: string;
  content: string;
  status: ContentStatus;
  content_type: ContentType;
  source_content_id: string | null;
  pillar_id: string | null;
  scheduled_at: string | null;
  target_account: TargetAccount;
  company_id: string;
  owner_id: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export type ContentStatus = 
  | 'draft'
  | 'in_review'
  | 'approved'
  | 'scheduled'
  | 'published'
  | 'failed';

export type ContentType =
  | 'text'
  | 'carousel'
  | 'video'
  | 'poll'
  | 'podcast_announcement';

export type TargetAccount = 
  | 'ceo_linkedin'
  | 'sourceco_linkedin'
  | 'captarget_linkedin';

// Generate these from database with something like:
// supabase gen types typescript --local > types/database.ts
```

---

#### 🟡 MODERATE: Enum-Like Values as Strings

**Current:**
```typescript
// Status values are strings with no type safety
const status = 'in_review';  // ✅ Valid
const status = 'in-review';  // ❌ Typo, but TypeScript won't catch it
```

**Better:**
```typescript
// Use TypeScript enums or const objects
export const ContentStatus = {
  DRAFT: 'draft',
  IN_REVIEW: 'in_review',
  APPROVED: 'approved',
  SCHEDULED: 'scheduled',
  PUBLISHED: 'published',
} as const;

export type ContentStatus = typeof ContentStatus[keyof typeof ContentStatus];

// Now typos are caught:
const status: ContentStatus = ContentStatus.IN_REVIEW;  // ✅
const status: ContentStatus = 'in-review';  // ❌ TypeScript error
```

---

### 11. Code Organization

#### 🟢 OPPORTUNITY: Monorepo Structure

**Current Structure (inferred):**
```
marketing-content-engine/
├── src/              (React frontend)
├── supabase/         (Edge functions + migrations)
└── ???
```

**Recommended:**
```
marketing-content-engine/
├── apps/
│   ├── web/                    (React frontend)
│   └── edge-functions/         (Supabase functions)
├── packages/
│   ├── shared/
│   │   ├── types/              (Shared TypeScript types)
│   │   ├── constants/          (Shared constants)
│   │   ├── utils/              (Date, formatting utils)
│   │   └── validators/         (Shared validation logic)
│   ├── database/
│   │   ├── migrations/         (Supabase migrations)
│   │   ├── seed/               (Seed data)
│   │   └── types.ts            (Generated DB types)
│   └── ui/                     (Shared React components)
└── tools/
    ├── scripts/                (Deployment, maintenance scripts)
    └── generators/             (Code generators)
```

---

## 🎯 PRIORITIZED REFACTORING ROADMAP

### Phase 1: Critical Data Integrity (Week 1)

**P0 - Data Layer Fixes:**
1. Add foreign key constraints
2. Add uniqueness constraints  
3. Create indexes on frequently queried columns
4. Standardize soft delete pattern
5. Separate templates from content (create `content_templates` table)

**P0 - Settings Management:**
1. Create shared constants file for AI defaults
2. Populate `ai_posting_settings` with defaults for all companies
3. Standardize timezone usage (pick Chicago or New York, stick with it)

**Estimated Effort:** 3-4 days  
**Impact:** Prevents data corruption, improves query performance

---

### Phase 2: Type Safety & Shared Code (Week 2)

**P1 - TypeScript Improvements:**
1. Generate types from database schema
2. Create strict interfaces for all entities
3. Use enums/const objects for status values
4. Add type guards for runtime validation

**P1 - Shared Utilities:**
1. Create `DateTimeUtils` class
2. Create `ScheduleCalculator` class
3. Create `ContentValidators` class
4. Extract constants to shared package

**Estimated Effort:** 5 days  
**Impact:** Reduces bugs, enables code reuse

---

### Phase 3: Frontend Stability (Week 3)

**P1 - React Query Fixes:**
1. Configure proper `staleTime` and `gcTime`
2. Add query key dependencies (include `companyId`)
3. Use mutations properly with `onSuccess` handlers
4. Remove optimistic updates (or implement correctly)

**P1 - Component Architecture:**
1. Add error boundaries
2. Make workspace filtering universal
3. Standardize loading/error states

**Estimated Effort:** 4 days  
**Impact:** Fixes race conditions, improves UX

---

### Phase 4: Backend Refactoring (Week 4)

**P2 - Edge Function Improvements:**
1. Add rate limiting
2. Improve error handling
3. Add structured logging
4. Extract reusable functions

**P2 - Database Optimization:**
1. Create views for common joins
2. Add computed columns where helpful
3. Review and optimize query patterns

**Estimated Effort:** 5 days  
**Impact:** Better performance, easier debugging

---

### Phase 5: Code Organization (Week 5)

**P2 - Monorepo Setup:**
1. Set up pnpm/yarn workspaces
2. Move shared code to packages
3. Configure builds and dependencies
4. Update deployment pipeline

**Estimated Effort:** 3-4 days  
**Impact:** Better code organization, easier to maintain

---

## 📊 METRICS TO TRACK

After refactoring, track these to ensure improvements:

**Code Quality:**
- TypeScript strict mode errors: 0
- ESLint warnings: < 10
- Test coverage: > 80%

**Performance:**
- Average query time: < 100ms
- Page load time: < 2s
- Edge function cold start: < 500ms

**Reliability:**
- Error rate: < 0.1%
- Failed scheduled posts: 0%
- Data consistency checks passing: 100%

---

## 🚀 IMMEDIATE ACTIONS

**Do Today:**
1. Add foreign key constraints to prevent orphaned data
2. Create default `ai_posting_settings` for all companies
3. Add uniqueness constraint on `queue_items(content_item_id, queue_id)`

**Do This Week:**
1. Extract date/time utilities to shared module
2. Fix React Query cache configuration
3. Add workspace filtering to all routes

**Do This Month:**
1. Complete Phase 1 (data integrity)
2. Complete Phase 2 (type safety)
3. Start Phase 3 (frontend stability)

---

## 💡 FINAL RECOMMENDATIONS

### Architectural Principles to Adopt

1. **Single Source of Truth:**
   - One place for defaults (not DB + code + frontend)
   - One place for business logic (shared package)
   - One place for types (generated from DB)

2. **Fail Fast:**
   - Add constraints at DB level
   - Validate early (frontend + backend)
   - Use TypeScript strict mode

3. **Explicit Over Implicit:**
   - Named constants instead of magic numbers
   - Clear function names (`calculateWeeklyCapacity` not `calc`)
   - Document complex business logic

4. **Consistent Patterns:**
   - Always soft delete OR always hard delete
   - Always use ISO weeks OR always use calendar weeks
   - Always filter by company OR never filter

5. **Defense in Depth:**
   - Frontend validation (UX)
   - Backend validation (enforcement)
   - Database constraints (last line of defense)

### Questions to Answer

Before implementing fixes, clarify:

1. **Timezone:** Chicago or New York? (Pick one and standardize)
2. **Week Definition:** ISO (Mon-Sun) or Calendar (Sun-Sat)?
3. **Delete Strategy:** Soft delete with audit trail OR hard delete?
4. **Company Filtering:** Default behavior for all pages?
5. **Settings Precedence:** What happens if user settings conflict with company settings?

---

**Ready to start? I recommend beginning with Phase 1 (data integrity) as it has the highest impact and prevents data corruption.**

Would you like me to generate the specific migration scripts, refactored code, or implementation plan for any of these phases?
