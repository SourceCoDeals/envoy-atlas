# Complete Implementation Guide
**Marketing Content Engine - Platform Refactor**

This guide ties together all the fixes (A-D) into a cohesive implementation plan.

---

## 🎯 OVERVIEW

We're fixing 4 major areas:
- **A) Data Integrity** - Database migrations, foreign keys, indexes
- **B) Shared Code** - Constants, types, utilities in shared package
- **C) React Query** - Cache management, race conditions
- **D) Schedule Logic** - Centralized ScheduleCalculator class

Plus resolving the **SourceCo/Captarget** workspace architecture.

---

## 📅 IMPLEMENTATION TIMELINE

### Week 1: Foundation (Data + Workspace)
- **Day 1-2:** Database migrations (A)
- **Day 3:** Workspace architecture (slugs, context)
- **Day 4-5:** Shared package setup (B)

### Week 2: Frontend Stability
- **Day 1-2:** React Query fixes (C)
- **Day 3-4:** ScheduleCalculator integration (D)
- **Day 5:** Testing and validation

### Week 3: AI Scheduler Integration
- **Day 1-2:** Refactor AI scheduler to use ScheduleCalculator
- **Day 3-4:** Fix distribution logic
- **Day 5:** End-to-end testing

### Week 4: Polish & Documentation
- **Day 1-2:** UI improvements
- **Day 3-4:** Documentation
- **Day 5:** Deployment

---

## 🚀 STEP-BY-STEP IMPLEMENTATION

## PHASE 1: DATABASE MIGRATIONS (Days 1-2)

### Step 1.1: Add Company Slugs

```bash
# Create migration file
supabase migration new add_company_slugs
```

```sql
-- Copy content from phase1-migrations.md → Migration 001
-- Add slugs, timezone, settings columns to companies table
```

**Test:**
```sql
SELECT * FROM get_company_by_slug('sourceco');
SELECT * FROM get_company_by_slug('captarget');
```

### Step 1.2: Add Foreign Keys

```bash
supabase migration new add_foreign_keys
```

```sql
-- Copy content from phase1-migrations.md → Migration 002
-- Add all foreign key constraints
```

**Test:**
```sql
-- Verify foreign keys exist
SELECT constraint_name, table_name
FROM information_schema.table_constraints
WHERE constraint_type = 'FOREIGN KEY'
  AND table_schema = 'public';
```

### Step 1.3: Add Unique Constraints

```bash
supabase migration new add_unique_constraints
```

```sql
-- Copy content from phase1-migrations.md → Migration 003
-- Prevent duplicate queue items, content packs, etc.
```

**Test:**
```sql
-- Try to insert duplicate - should fail
INSERT INTO queue_items (content_item_id, queue_id)
VALUES ('existing-id', 'existing-queue')
-- Should throw unique constraint violation
```

### Step 1.4: Remaining Migrations

Apply migrations 004-010 from `phase1-migrations.md`:
- 004: Soft delete views
- 005: Performance indexes
- 006: Separate templates
- 007: Status audit trail
- 008: Initialize AI settings
- 009: Content metadata
- 010: Helpful views

**Deploy:**
```bash
supabase db push
```

**Verify:**
```bash
# Check all migrations applied
supabase migration list

# Run verification queries
supabase db sql < verify-migrations.sql
```

---

## PHASE 2: WORKSPACE ARCHITECTURE (Day 3)

### Step 2.1: Create Workspace Context

**File:** `src/contexts/WorkspaceContext.tsx`

```typescript
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import type { Company } from '@marketing-engine/shared/types';

interface WorkspaceContextValue {
  workspace: Company | null;
  workspaceSlug: string;
  setWorkspaceSlug: (slug: string) => void;
  isLoading: boolean;
}

const WorkspaceContext = createContext<WorkspaceContextValue | undefined>(
  undefined
);

export function WorkspaceProvider({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [workspaceSlug, setWorkspaceSlug] = useState<string>('sourceco');

  // Auto-detect workspace from URL
  useEffect(() => {
    const match = location.pathname.match(/\/workspace\/([^\/]+)/);
    if (match) {
      setWorkspaceSlug(match[1]);
    }
  }, [location.pathname]);

  // Fetch workspace data
  const { data: workspace, isLoading } = useQuery({
    queryKey: ['workspace', workspaceSlug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('slug', workspaceSlug)
        .single();

      if (error) throw error;
      return data as Company;
    },
    enabled: !!workspaceSlug,
  });

  // Switch workspace helper
  const switchWorkspace = (slug: string) => {
    setWorkspaceSlug(slug);
    // Update URL to reflect workspace
    navigate(`/workspace/${slug}/dashboard`);
  };

  return (
    <WorkspaceContext.Provider
      value={{
        workspace: workspace || null,
        workspaceSlug,
        setWorkspaceSlug: switchWorkspace,
        isLoading,
      }}
    >
      {children}
    </WorkspaceContext.Provider>
  );
}

export function useWorkspace() {
  const context = useContext(WorkspaceContext);
  if (!context) {
    throw new Error('useWorkspace must be used within WorkspaceProvider');
  }
  return context;
}
```

### Step 2.2: Update Routes

**File:** `src/App.tsx`

```typescript
import { WorkspaceProvider } from '@/contexts/WorkspaceContext';

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WorkspaceProvider>
        <Routes>
          {/* Workspace routes */}
          <Route path="/workspace/:workspaceSlug" element={<WorkspaceLayout />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="pipeline" element={<Pipeline />} />
            <Route path="calendar" element={<Calendar />} />
            <Route path="queues" element={<Queues />} />
            {/* Add all other routes */}
          </Route>

          {/* Non-workspace routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/settings/profile" element={<Profile />} />
          
          {/* Redirect root to default workspace */}
          <Route path="/" element={<Navigate to="/workspace/sourceco/dashboard" replace />} />
        </Routes>
      </WorkspaceProvider>
    </QueryClientProvider>
  );
}
```

### Step 2.3: Add Workspace Indicator

**File:** `src/components/Header.tsx`

```typescript
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Building2 } from 'lucide-react';

export function Header() {
  const { workspace, setWorkspaceSlug } = useWorkspace();

  return (
    <header className="border-b">
      <div className="flex items-center justify-between px-6 py-3">
        <div className="flex items-center gap-4">
          {/* Logo */}
          <Logo />
          
          {/* Workspace Indicator */}
          <div className="flex items-center gap-2 px-3 py-1 bg-blue-50 rounded-md">
            <Building2 className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">
              {workspace?.name}
            </span>
          </div>
          
          {/* Workspace Switcher */}
          <select
            value={workspace?.slug}
            onChange={(e) => setWorkspaceSlug(e.target.value)}
            className="text-sm border rounded px-2 py-1"
          >
            <option value="sourceco">SourceCo</option>
            <option value="captarget">Captarget</option>
          </select>
        </div>
        
        {/* Rest of header */}
      </div>
    </header>
  );
}
```

**Test:**
- Navigate to `/workspace/sourceco/dashboard`
- Switch workspace using dropdown
- Verify URL updates and content filters

---

## PHASE 3: SHARED PACKAGE (Days 4-5)

### Step 3.1: Create Package Structure

```bash
mkdir -p packages/shared/src/{constants,types,utils,services}
cd packages/shared
npm init -y
```

### Step 3.2: Copy Files

Copy all files from `shared-package.md`:
- `package.json`
- `tsconfig.json`
- `src/constants/*.ts`
- `src/types/*.ts`
- `src/utils/*.ts`
- `src/services/ScheduleCalculator.ts` (from schedule-calculator.md)
- `src/index.ts`

### Step 3.3: Install Dependencies

```bash
npm install zod
npm install -D typescript vitest
```

### Step 3.4: Build Package

```bash
npm run build
```

### Step 3.5: Link to Apps

**Root `package.json`:**
```json
{
  "workspaces": [
    "apps/*",
    "packages/*"
  ]
}
```

**In `apps/web/package.json` and `apps/edge-functions/package.json`:**
```json
{
  "dependencies": {
    "@marketing-engine/shared": "workspace:*"
  }
}
```

```bash
# Install workspace dependencies
npm install
```

**Test:**
```typescript
// In any app file
import { AI_POSTING_DEFAULTS } from '@marketing-engine/shared';
console.log(AI_POSTING_DEFAULTS.tom_target_posts_per_day); // 2
```

---

## PHASE 4: REACT QUERY FIXES (Days 1-2 of Week 2)

### Step 4.1: Update Query Client Config

**File:** `src/lib/queryClient.ts`

```typescript
// Copy from react-query-fixes.md → Fix 5
```

### Step 4.2: Create useWorkspaceQuery Hook

**File:** `src/hooks/useWorkspaceQuery.tsx`

```typescript
// Copy from react-query-fixes.md → Fix 2
```

### Step 4.3: Update useContentItems

**File:** `src/hooks/useContentItems.tsx`

```typescript
// Copy from react-query-fixes.md → Fix 1
```

### Step 4.4: Fix useQueueChat

**File:** `src/hooks/useQueueChat.tsx`

```typescript
// Copy from react-query-fixes.md → Fix 3
```

### Step 4.5: Update Mutations

**File:** `src/hooks/useContentMutations.tsx`

```typescript
// Copy from react-query-fixes.md → Fix 4
```

**Test:**
1. Switch between workspaces → no data leakage
2. Send message, immediately send "confirm" → history is complete
3. Create/update/delete content → no duplicates in UI

---

## PHASE 5: SCHEDULE CALCULATOR (Days 3-4 of Week 2)

### Step 5.1: Add to Shared Package

Already done in Phase 3! The ScheduleCalculator is in `packages/shared/src/services/`

### Step 5.2: Update Edge Function to Use Calculator

**File:** `supabase/functions/ai-schedule-assistant/index.ts`

```typescript
import { ScheduleCalculator } from '@marketing-engine/shared/services';
import { AI_POSTING_DEFAULTS } from '@marketing-engine/shared/constants';

// In scheduling logic:
const settings = dbSettings || AI_POSTING_DEFAULTS;
const calculator = new ScheduleCalculator(settings);

// Replace all inline calculations:

// BEFORE:
const weeklyMax = queue.name === 'sourceco_linkedin' ? 5 : 10;

// AFTER:
const weeklyLimit = calculator.getWeeklyLimit(queue.target_account);
const weeklyMax = weeklyLimit.max;

// BEFORE:
const postsThisWeek = scheduledItems.filter(item => 
  item.target_account === queue.target_account &&
  // ... date checks
).length;
const remaining = weeklyMax - postsThisWeek;

// AFTER:
const weekBounds = calculator.getWeekBounds(startDate);
const remaining = calculator.calculateWeeklyCapacity(
  queue.target_account,
  weekBounds,
  scheduledItems
);
```

### Step 5.3: Add Capacity Display to Frontend

**File:** `src/components/CapacityWidget.tsx`

```typescript
// Copy example from schedule-calculator.md → Usage Examples → Frontend
```

**Test:**
- Verify weekly limits match between frontend and backend
- Schedule content → capacity updates correctly
- Switch workspace → capacity recalculates

---

## PHASE 6: AI SCHEDULER INTEGRATION (Days 1-2 of Week 3)

### Step 6.1: Review Current Implementation

```typescript
// Current ai-schedule-assistant/index.ts has:
// - distributor.ts
// - validators.ts
// - slot-finder.ts
// - podcast-context.ts

// But these aren't being called properly!
```

### Step 6.2: Refactor Main Scheduling Flow

**File:** `supabase/functions/ai-schedule-assistant/index.ts`

```typescript
import { ScheduleCalculator } from '@marketing-engine/shared/services';
import { loadScheduleContext } from './lib/context-loader.ts';
import { distributeAcrossWeeks } from './lib/distributor.ts';

// In schedule_posts action:
async function handleSchedulePosts(action: ScheduleAction) {
  const { queue_name, start_date, items_to_schedule } = action.parameters;
  
  // 1. Get settings and initialize calculator
  const settings = await getAIPostingSettings(companyId);
  const calculator = new ScheduleCalculator(settings);
  
  // 2. Load full month context (THIS WAS MISSING!)
  const targetMonth = new Date(start_date);
  const context = await loadScheduleContext(
    companyId,
    targetMonth,
    supabase
  );
  
  // 3. Get queue and items
  const queue = await getQueue(queue_name);
  const queueItems = await getQueueItems(queue.id, items_to_schedule);
  
  // 4. Use distribution function (THIS WAS NOT BEING CALLED!)
  const distribution = await distributeAcrossWeeks(
    queueItems,
    queue,
    new Date(start_date),
    context,
    settings,
    calculator
  );
  
  // 5. Actually schedule the distributed items
  const scheduled = [];
  for (const item of distribution.scheduledItems) {
    const result = await scheduleContentItem(
      item.id,
      item.scheduledAt,
      queue.target_account
    );
    scheduled.push(result);
  }
  
  return {
    scheduled,
    warnings: distribution.warnings,
    blocked: distribution.blocked,
  };
}
```

### Step 6.3: Implement Missing Context Loader

**File:** `supabase/functions/ai-schedule-assistant/lib/context-loader.ts`

```typescript
import { ScheduleCalculator } from '@marketing-engine/shared/services';

export async function loadScheduleContext(
  companyId: string,
  targetMonth: Date,
  supabase: any
) {
  const calculator = new ScheduleCalculator();
  const monthBounds = calculator.getMonthBounds(targetMonth);
  
  // Query all scheduled items for the month
  const { data: scheduledItems, error } = await supabase
    .from('content_items')
    .select('*')
    .eq('company_id', companyId)
    .gte('scheduled_at', monthBounds.start.toISOString())
    .lte('scheduled_at', monthBounds.end.toISOString())
    .in('status', ['scheduled', 'published']);
  
  if (error) throw error;
  
  // Build weekly and daily totals
  const weeklyTotals: Record<string, Record<string, number>> = {};
  const dailyTotals: Record<string, Record<string, number>> = {};
  
  for (const item of scheduledItems || []) {
    const date = new Date(item.scheduled_at);
    const weekBounds = calculator.getWeekBounds(date);
    const weekKey = `${weekBounds.start.toISOString().split('T')[0]}`;
    const dayKey = date.toISOString().split('T')[0];
    const account = item.target_account;
    
    // Weekly
    if (!weeklyTotals[weekKey]) weeklyTotals[weekKey] = {};
    weeklyTotals[weekKey][account] = (weeklyTotals[weekKey][account] || 0) + 1;
    
    // Daily
    if (!dailyTotals[dayKey]) dailyTotals[dayKey] = {};
    dailyTotals[dayKey][account] = (dailyTotals[dayKey][account] || 0) + 1;
  }
  
  return {
    monthStart: monthBounds.start,
    monthEnd: monthBounds.end,
    scheduledItems: scheduledItems || [],
    weeklyTotals,
    dailyTotals,
    getWeeklyCapacity: (weekKey: string, account: string, settings: any) => {
      const used = weeklyTotals[weekKey]?.[account] || 0;
      const calc = new ScheduleCalculator(settings);
      const limit = calc.getWeeklyLimit(account);
      return limit.max - used;
    },
  };
}
```

### Step 6.4: Update Distributor to Use Calculator

**File:** `supabase/functions/ai-schedule-assistant/lib/distributor.ts`

```typescript
import { ScheduleCalculator } from '@marketing-engine/shared/services';

export async function distributeAcrossWeeks(
  items: any[],
  queue: any,
  startDate: Date,
  context: any,
  settings: any,
  calculator: ScheduleCalculator
) {
  const scheduledItems = [];
  const warnings = [];
  const blocked = [];
  
  // Sort by priority
  const sortedItems = [...items].sort((a, b) => {
    const scoreA = calculator.calculatePriorityScore(a.content_type, !!a.podcast_episode_id);
    const scoreB = calculator.calculatePriorityScore(b.content_type, !!b.podcast_episode_id);
    return scoreB - scoreA;
  });
  
  let currentDate = new Date(startDate);
  const maxWeeksAhead = 4;
  let weeksChecked = 0;
  
  for (const item of sortedItems) {
    let scheduled = false;
    weeksChecked = 0;
    
    while (!scheduled && weeksChecked < maxWeeksAhead) {
      const weekBounds = calculator.getWeekBounds(currentDate);
      const weekKey = weekBounds.start.toISOString().split('T')[0];
      
      // Check weekly capacity
      const weeklyCapacity = context.getWeeklyCapacity(
        weekKey,
        queue.target_account,
        settings
      );
      
      if (weeklyCapacity <= 0) {
        // Move to next week
        currentDate = new Date(weekBounds.end);
        currentDate.setDate(currentDate.getDate() + 1);
        weeksChecked++;
        continue;
      }
      
      // Find slot within this week
      let dayDate = new Date(weekBounds.start);
      while (dayDate <= weekBounds.end && !scheduled) {
        // Skip weekends if not allowed
        if (calculator.isWeekend(dayDate) && !calculator.isWeekendAllowed()) {
          dayDate.setDate(dayDate.getDate() + 1);
          continue;
        }
        
        // Check daily capacity
        const dailyCapacity = calculator.calculateDailyCapacity(
          queue.target_account,
          dayDate,
          context.scheduledItems
        );
        
        if (dailyCapacity > 0) {
          // Find best slot
          const bestSlot = calculator.findBestSlot(
            dayDate,
            queue.target_account,
            item.content_type,
            context.scheduledItems
          );
          
          if (bestSlot) {
            // Validate spacing
            const spacingCheck = calculator.validateContentTypeSpacing(
              item.content_type,
              bestSlot.datetime,
              queue.target_account,
              context.scheduledItems
            );
            
            const finalTime = spacingCheck.valid
              ? bestSlot.datetime
              : spacingCheck.adjustedTime!;
            
            scheduledItems.push({
              ...item,
              scheduledAt: finalTime,
              slotTier: bestSlot.tier,
              weekNumber: weekKey,
            });
            
            // Add to context so next items see this one
            context.scheduledItems.push({
              ...item,
              scheduledAt: finalTime,
              target_account: queue.target_account,
            });
            
            if (!spacingCheck.valid) {
              warnings.push(spacingCheck.warning!);
            }
            
            scheduled = true;
          }
        }
        
        dayDate.setDate(dayDate.getDate() + 1);
      }
      
      if (!scheduled) {
        // Move to next week
        currentDate = new Date(weekBounds.end);
        currentDate.setDate(currentDate.getDate() + 1);
        weeksChecked++;
      }
    }
    
    if (!scheduled) {
      blocked.push({
        item,
        reason: `Could not find slot within ${maxWeeksAhead} weeks`,
      });
    }
  }
  
  return { scheduledItems, warnings, blocked };
}
```

**Test:**
1. Schedule 5 items → should spread across multiple days
2. Schedule 8 SourceCo items → only 5 scheduled, 3 blocked with warning
3. Check logs → verify context is loaded, distributor is called
4. Verify weekly limits are enforced

---

## PHASE 7: TESTING (Day 5 of Week 3)

### Test Scenarios

**Test 1: Basic Distribution**
```
Input: 5 items, 1 queue, start_date = Monday
Expected: Items spread across Mon-Fri (not all on Monday)
```

**Test 2: Weekly Limits**
```
Input: 8 items for SourceCo (max 5/week)
Expected: 5 scheduled this week, 3 scheduled next week with warning
```

**Test 3: Podcast Release Date**
```
Input: Podcast clip, episode releases Friday, try to schedule Thursday
Expected: Blocked with warning, adjusted to Friday or later
```

**Test 4: Content Type Spacing**
```
Input: 2 carousels, 2 hours apart
Expected: Second carousel moved to +24 hours with warning
```

**Test 5: Cross-Account Spacing**
```
Input: Same content on CEO and SourceCo, 12 hours apart
Expected: Second post moved to +36 hours with warning
```

**Test 6: Workspace Isolation**
```
Input: Switch from SourceCo to Captarget workspace
Expected: Different content, different capacity, no data leakage
```

---

## PHASE 8: DEPLOYMENT (Days 1-5 of Week 4)

### Pre-Deployment Checklist

- [ ] All migrations applied to staging
- [ ] Shared package built and linked
- [ ] Edge functions updated and tested
- [ ] Frontend queries using workspace context
- [ ] ScheduleCalculator integrated everywhere
- [ ] No hardcoded company UUIDs remaining
- [ ] All queries include workspace.id in key
- [ ] AI scheduler uses distribution logic
- [ ] Tests passing

### Deployment Steps

1. **Deploy Database Migrations**
```bash
# Backup production DB
supabase db dump > backup-$(date +%Y%m%d).sql

# Apply migrations
supabase db push --prod
```

2. **Deploy Edge Functions**
```bash
supabase functions deploy ai-schedule-assistant
```

3. **Deploy Frontend**
```bash
npm run build
# Deploy to hosting (Vercel, Netlify, etc.)
```

4. **Verify Production**
- [ ] Workspace switching works
- [ ] Content filters by workspace
- [ ] Scheduling spreads across days
- [ ] Weekly limits enforced
- [ ] No duplicate items in UI

### Rollback Plan

If issues arise:

```bash
# Rollback edge functions
supabase functions delete ai-schedule-assistant
supabase functions deploy ai-schedule-assistant@previous

# Rollback database
psql < backup-YYYYMMDD.sql

# Rollback frontend
# Redeploy previous version
```

---

## 📊 SUCCESS METRICS

After deployment, track:

**Technical Metrics:**
- TypeScript errors: 0
- Test coverage: >80%
- Query response time: <100ms average
- Cache hit rate: >90%

**Functional Metrics:**
- Scheduled posts spread across multiple days: Yes
- Weekly limits enforced: Yes
- No duplicate content items: Yes
- Workspace isolation working: Yes

**User Experience:**
- Workspace switching smooth: Yes
- Calendar shows correct content: Yes
- AI scheduler distributes properly: Yes
- No "which company am I in?" confusion: Yes

---

## 🎓 LESSONS LEARNED

Document these during implementation:

1. **What worked well:**
   - Migrations in sequence
   - Shared package structure
   - ScheduleCalculator abstraction

2. **What was challenging:**
   - React Query cache timing
   - AI scheduler integration
   - Testing edge functions locally

3. **What would we do differently:**
   - Start with tests earlier
   - Use more granular migrations
   - Better logging from day 1

---

## 📚 DOCUMENTATION TO CREATE

After implementation:

1. **Architecture Decision Records (ADRs)**
   - Why we chose slugs over UUIDs
   - Why we kept companies separate
   - Why we centralized ScheduleCalculator

2. **Developer Guide**
   - How to add a new company
   - How to add a new scheduling rule
   - How to query content by workspace

3. **Troubleshooting Guide**
   - What if scheduling puts everything on one day?
   - What if workspace switching shows wrong data?
   - What if cache gets stale?

4. **Testing Guide**
   - How to test scheduling logic
   - How to test workspace isolation
   - How to test React Query cache

---

## ✅ COMPLETION CRITERIA

The refactor is complete when:

- [x] All 10 migrations applied successfully
- [x] Shared package built and used in all apps
- [x] React Query uses workspace-aware keys
- [x] ScheduleCalculator used in frontend + backend
- [x] AI scheduler distributes across multiple days
- [x] Weekly limits enforced by code, not just prompt
- [x] Workspace switching works on all pages
- [x] No hardcoded UUIDs in codebase
- [x] No duplicate items in UI
- [x] Tests passing
- [x] Documentation complete
- [x] Production deployment successful

---

**You've now got a complete roadmap from current state to fully refactored platform!**

Would you like me to create any specific files or dive deeper into any particular phase?
