# React Query Cache Management Fixes

Fix the race conditions, stale data, and duplicate rendering issues in React Query usage.

---

## Problem Summary

1. **Race Condition:** User sends "confirm" before cache refetches conversation history
2. **Duplicate Items:** Content items appearing twice in Pipeline (cache merging old + new)
3. **Optimistic Updates:** Fragile implementation causing mismatches
4. **Missing Keys:** Company ID not in query keys, causing cross-contamination

---

## Fix 1: Proper Query Key Structure

### File: src/hooks/useContentItems.tsx

```typescript
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import type { ContentItem } from '@marketing-engine/shared/types';

export function useContentItems() {
  const { workspace } = useWorkspace();
  const queryClient = useQueryClient();

  const query = useQuery({
    // ✅ Include workspace.id in key to prevent cross-contamination
    queryKey: ['content-items', workspace?.id],
    
    queryFn: async () => {
      if (!workspace?.id) {
        throw new Error('No workspace selected');
      }

      const { data, error } = await supabase
        .from('content_items')
        .select(`
          *,
          owner:profiles(id, name, email),
          template:content_templates(id, title),
          episode:podcast_episodes(id, episode_title, release_date)
        `)
        .eq('company_id', workspace.id)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // ✅ Deduplicate by ID (safety net)
      const uniqueItems = Array.from(
        new Map((data || []).map(item => [item.id, item])).values()
      );

      return uniqueItems as ContentItem[];
    },

    // ✅ Cache configuration to prevent stale data issues
    enabled: !!workspace?.id,
    staleTime: 0,              // Data is stale immediately after fetch
    gcTime: 1000 * 60 * 5,     // Keep in cache for 5 minutes
    refetchOnMount: true,      // Always refetch when component mounts
    refetchOnWindowFocus: false, // Don't refetch on tab switch (too aggressive)

    // ✅ Select function with deduplication
    select: (data) => {
      // Additional deduplication at select level
      return Array.from(
        new Map(data.map(item => [item.id, item])).values()
      );
    },
  });

  // ✅ Helper to invalidate content items
  const invalidateContentItems = () => {
    return queryClient.invalidateQueries({
      queryKey: ['content-items', workspace?.id],
    });
  };

  // ✅ Helper to refetch and wait
  const refetchContentItems = async () => {
    await queryClient.invalidateQueries({
      queryKey: ['content-items', workspace?.id],
    });
    return await queryClient.refetchQueries({
      queryKey: ['content-items', workspace?.id],
    });
  };

  return {
    ...query,
    contentItems: query.data || [],
    invalidateContentItems,
    refetchContentItems,
  };
}
```

---

## Fix 2: Workspace-Aware Query Hook

### File: src/hooks/useWorkspaceQuery.tsx

```typescript
import { useQuery, UseQueryOptions } from '@tanstack/react-query';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';

/**
 * Workspace-aware query hook
 * 
 * Automatically filters by workspace and includes workspace.id in query key
 * to prevent cache pollution across workspaces
 */
export function useWorkspaceQuery<T = any>(
  tableName: string,
  options?: {
    select?: string;
    filter?: Record<string, any>;
    orderBy?: { column: string; ascending?: boolean };
    enabled?: boolean;
  }
) {
  const { workspace } = useWorkspace();

  return useQuery({
    queryKey: [tableName, workspace?.id, options?.filter, options?.orderBy],
    
    queryFn: async () => {
      if (!workspace?.id) {
        throw new Error('No workspace selected');
      }

      let query = supabase
        .from(tableName)
        .select(options?.select || '*')
        .eq('company_id', workspace.id);

      // Apply filters
      if (options?.filter) {
        Object.entries(options.filter).forEach(([key, value]) => {
          query = query.eq(key, value);
        });
      }

      // Apply ordering
      if (options?.orderBy) {
        query = query.order(
          options.orderBy.column,
          { ascending: options.orderBy.ascending ?? false }
        );
      }

      const { data, error } = await query;
      
      if (error) throw error;
      return data as T[];
    },

    enabled: !!workspace?.id && (options?.enabled !== false),
    staleTime: 0,
    gcTime: 1000 * 60 * 5,
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });
}

// Usage example:
// const { data: contentItems } = useWorkspaceQuery<ContentItem>('content_items', {
//   filter: { status: 'in_review' },
//   orderBy: { column: 'created_at', ascending: false }
// });
```

---

## Fix 3: Queue Chat with Proper Conversation History

### File: src/hooks/useQueueChat.tsx

```typescript
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import { useState } from 'react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}

export function useQueueChat() {
  const { workspace } = useWorkspace();
  const queryClient = useQueryClient();
  const [isProcessing, setIsProcessing] = useState(false);

  // Query for chat messages
  const { data: messages = [] } = useQuery({
    queryKey: ['queue-chat-messages', workspace?.id],
    queryFn: async () => {
      if (!workspace?.id) return [];

      const { data, error } = await supabase
        .from('queue_chat_messages')
        .select('*')
        .eq('company_id', workspace.id)
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data as ChatMessage[];
    },
    enabled: !!workspace?.id,
    staleTime: 0,
    gcTime: 1000 * 60 * 5,
  });

  // Mutation for sending messages
  const sendMessage = useMutation({
    mutationFn: async (message: string) => {
      if (!workspace?.id) {
        throw new Error('No workspace selected');
      }

      setIsProcessing(true);

      try {
        // 1. Save user message to DB
        const { data: userMsg, error: userError } = await supabase
          .from('queue_chat_messages')
          .insert({
            company_id: workspace.id,
            role: 'user',
            content: message,
          })
          .select()
          .single();

        if (userError) throw userError;

        // 2. Wait for cache to update with user message
        await queryClient.invalidateQueries({
          queryKey: ['queue-chat-messages', workspace.id],
        });
        await queryClient.refetchQueries({
          queryKey: ['queue-chat-messages', workspace.id],
        });

        // 3. Get fresh conversation history (guaranteed to include user message)
        const freshMessages = queryClient.getQueryData<ChatMessage[]>([
          'queue-chat-messages',
          workspace.id,
        ]) || [];

        // 4. Build conversation history for AI (last 10 messages)
        const conversationHistory = freshMessages
          .slice(-10)
          .map(m => ({
            role: m.role,
            content: m.content,
          }));

        // 5. Call AI edge function
        const response = await fetch('/api/ai-schedule-assistant', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message,
            companyId: workspace.id,
            conversationHistory, // ✅ Fresh history guaranteed
          }),
        });

        if (!response.ok) {
          throw new Error('AI request failed');
        }

        const aiResponse = await response.json();

        // 6. Save AI response to DB
        const { error: aiError } = await supabase
          .from('queue_chat_messages')
          .insert({
            company_id: workspace.id,
            role: 'assistant',
            content: aiResponse.message,
          });

        if (aiError) throw aiError;

        // 7. Final refetch to include AI response
        await queryClient.invalidateQueries({
          queryKey: ['queue-chat-messages', workspace.id],
        });
        await queryClient.refetchQueries({
          queryKey: ['queue-chat-messages', workspace.id],
        });

        return aiResponse;
      } finally {
        setIsProcessing(false);
      }
    },

    onError: (error) => {
      console.error('Failed to send message:', error);
      setIsProcessing(false);
    },
  });

  // Helper to clear chat
  const clearChat = async () => {
    if (!workspace?.id) return;

    await supabase
      .from('queue_chat_messages')
      .delete()
      .eq('company_id', workspace.id);

    queryClient.invalidateQueries({
      queryKey: ['queue-chat-messages', workspace.id],
    });
  };

  return {
    messages,
    sendMessage: sendMessage.mutateAsync,
    isProcessing,
    isSending: sendMessage.isPending,
    clearChat,
  };
}
```

**Key Improvements:**
1. ✅ **Wait for refetch** after saving user message
2. ✅ **Read from fresh cache** to build conversation history
3. ✅ **No optimistic updates** - rely on DB as source of truth
4. ✅ **Sequential operations** - no race conditions
5. ✅ **Clear loading states** - user knows when AI is processing

---

## Fix 4: Mutation Best Practices

### File: src/hooks/useContentMutations.tsx

```typescript
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import type { ContentItem } from '@marketing-engine/shared/types';

export function useContentMutations() {
  const { workspace } = useWorkspace();
  const queryClient = useQueryClient();

  // ✅ Proper mutation with invalidation
  const createContentItem = useMutation({
    mutationFn: async (data: Partial<ContentItem>) => {
      if (!workspace?.id) {
        throw new Error('No workspace selected');
      }

      const { data: newItem, error } = await supabase
        .from('content_items')
        .insert({
          ...data,
          company_id: workspace.id,
        })
        .select()
        .single();

      if (error) throw error;
      return newItem as ContentItem;
    },

    onSuccess: (newItem) => {
      // Invalidate and refetch
      queryClient.invalidateQueries({
        queryKey: ['content-items', workspace.id],
      });
      
      // Show success toast
      console.log('Content created:', newItem.title);
    },

    onError: (error) => {
      console.error('Failed to create content:', error);
      // Show error toast
    },
  });

  // ✅ Update with optimistic updates (proper implementation)
  const updateContentItem = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<ContentItem> }) => {
      const { data, error } = await supabase
        .from('content_items')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data as ContentItem;
    },

    // ✅ Optimistic update (optional - only if you need instant UI feedback)
    onMutate: async ({ id, updates }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({
        queryKey: ['content-items', workspace?.id],
      });

      // Snapshot previous value
      const previousItems = queryClient.getQueryData<ContentItem[]>([
        'content-items',
        workspace?.id,
      ]);

      // Optimistically update
      if (previousItems) {
        queryClient.setQueryData<ContentItem[]>(
          ['content-items', workspace?.id],
          previousItems.map(item =>
            item.id === id ? { ...item, ...updates } : item
          )
        );
      }

      // Return context with previous value
      return { previousItems };
    },

    onError: (error, variables, context) => {
      // Rollback on error
      if (context?.previousItems) {
        queryClient.setQueryData(
          ['content-items', workspace?.id],
          context.previousItems
        );
      }
      console.error('Failed to update content:', error);
    },

    onSettled: () => {
      // Always refetch after error or success
      queryClient.invalidateQueries({
        queryKey: ['content-items', workspace?.id],
      });
    },
  });

  // ✅ Delete mutation
  const deleteContentItem = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('content_items')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;
    },

    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ['content-items', workspace?.id],
      });
    },
  });

  return {
    createContentItem: createContentItem.mutateAsync,
    updateContentItem: updateContentItem.mutateAsync,
    deleteContentItem: deleteContentItem.mutateAsync,
    isCreating: createContentItem.isPending,
    isUpdating: updateContentItem.isPending,
    isDeleting: deleteContentItem.isPending,
  };
}
```

---

## Fix 5: Global Query Configuration

### File: src/lib/queryClient.ts

```typescript
import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // ✅ Global defaults
      staleTime: 0,              // Data is stale immediately
      gcTime: 1000 * 60 * 5,     // Cache for 5 minutes
      refetchOnMount: true,       // Always refetch on mount
      refetchOnWindowFocus: false, // Don't refetch on focus (prevents double-fetches)
      retry: 1,                   // Retry failed queries once
      
      // ✅ Error handling
      throwOnError: false,        // Don't throw errors by default
    },
    
    mutations: {
      // ✅ Mutation defaults
      retry: 0,                   // Don't retry mutations
      throwOnError: false,
    },
  },
});
```

---

## Fix 6: Prevent Cache Contamination in Tests

### File: src/test/utils/queryClient.ts

```typescript
import { QueryClient } from '@tanstack/react-query';

/**
 * Create a fresh query client for each test
 * Prevents test pollution
 */
export function createTestQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: Infinity, // Don't garbage collect in tests
        staleTime: Infinity, // Keep data fresh in tests
      },
      mutations: {
        retry: false,
      },
    },
    logger: {
      log: () => {},
      warn: () => {},
      error: () => {},
    },
  });
}

// Usage in tests:
// const queryClient = createTestQueryClient();
// wrapper: ({ children }) => (
//   <QueryClientProvider client={queryClient}>
//     {children}
//   </QueryClientProvider>
// )
```

---

## Summary of Changes

### Before (Problems):
❌ No company ID in query keys → cache pollution  
❌ Optimistic updates without proper rollback → mismatches  
❌ Race conditions on rapid mutations → stale conversation history  
❌ Manual deduplication scattered everywhere → inconsistent  
❌ No refetch awaiting → "confirm" sees stale data

### After (Fixed):
✅ Company ID in all query keys → isolated caches  
✅ Proper optimistic updates with rollback → consistent state  
✅ Sequential operations with awaited refetches → no race conditions  
✅ Centralized deduplication → DRY principle  
✅ Await refetch before next operation → fresh data guaranteed

---

## Migration Steps

1. **Update query hooks:**
   - Add workspace.id to all query keys
   - Configure staleTime and gcTime
   - Add deduplication in select

2. **Fix useQueueChat:**
   - Remove optimistic updates
   - Await refetch after each DB write
   - Read from cache only after refetch completes

3. **Update mutations:**
   - Use onSuccess for invalidation
   - Use onSettled for guaranteed refetch
   - Only use optimistic updates where needed

4. **Test thoroughly:**
   - Switch between workspaces
   - Send rapid messages in queue chat
   - Check for duplicate items

5. **Monitor in production:**
   - Watch for duplicate items
   - Check cache hit rates
   - Verify no cross-workspace data leaks
