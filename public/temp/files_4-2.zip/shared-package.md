# Shared Constants & Types Package

Create a shared package that can be used by frontend, edge functions, and tests.

---

## Package Structure

```
packages/shared/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts              (Main export)
│   ├── constants/
│   │   ├── index.ts
│   │   ├── ai-posting.ts      (AI posting defaults)
│   │   ├── scheduling.ts      (Scheduling constants)
│   │   └── content.ts         (Content types, statuses)
│   ├── types/
│   │   ├── index.ts
│   │   ├── database.ts        (Generated from Supabase)
│   │   ├── content.ts         (Content-related types)
│   │   ├── scheduling.ts      (Scheduling types)
│   │   └── company.ts         (Company/workspace types)
│   ├── utils/
│   │   ├── index.ts
│   │   ├── datetime.ts        (Date/time utilities)
│   │   └── validation.ts      (Validation helpers)
│   └── validators/
│       ├── index.ts
│       ├── content.ts         (Content validation)
│       └── scheduling.ts      (Schedule validation)
└── README.md
```

---

## File: packages/shared/package.json

```json
{
  "name": "@marketing-engine/shared",
  "version": "1.0.0",
  "description": "Shared constants, types, and utilities for Marketing Content Engine",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc",
    "dev": "tsc --watch",
    "typecheck": "tsc --noEmit",
    "test": "vitest"
  },
  "exports": {
    ".": "./dist/index.js",
    "./constants": "./dist/constants/index.js",
    "./types": "./dist/types/index.js",
    "./utils": "./dist/utils/index.js",
    "./validators": "./dist/validators/index.js"
  },
  "dependencies": {
    "zod": "^3.22.4"
  },
  "devDependencies": {
    "typescript": "^5.3.3",
    "vitest": "^1.1.0"
  }
}
```

---

## File: packages/shared/tsconfig.json

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "lib": ["ES2022"],
    "declaration": true,
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
```

---

## File: packages/shared/src/constants/ai-posting.ts

```typescript
/**
 * AI Posting Settings Defaults
 * 
 * These defaults are used when:
 * 1. Creating new companies
 * 2. As fallback when DB settings are missing
 * 3. In tests
 * 
 * SINGLE SOURCE OF TRUTH - Do not duplicate these values elsewhere
 */

export const AI_POSTING_DEFAULTS = {
  // CEO (Tom) Posting Rules
  tom_target_posts_per_day: 2,
  allow_second_post_tom: true,
  min_hours_between_tom_posts: 6,
  
  // SourceCo Posting Rules
  sourceco_posts_per_week_min: 3,
  sourceco_posts_per_week_max: 5,
  
  // Captarget Posting Rules
  captarget_posts_per_week_min: 3,
  captarget_posts_per_week_max: 5,
  
  // Content Type Spacing Rules
  min_hours_between_any_posts: 4,
  carousel_after_carousel_hours: 24,
  video_after_video_hours: 24,
  poll_cooldown_hours: 72,
  
  // Cross-Account Rules
  cross_account_same_idea_hours: 36,
  same_source_same_account_hours: 72,
  same_pillar_same_account_hours: 48,
  same_source_cross_account_hours: 36,
  same_pillar_cross_account_hours: 24,
  
  // Podcast Rules
  podcast_distribution_window_days: 10,
  podcast_pre_announcement_days: 7,
  max_podcast_posts_per_day: 2,
  
  // General Rules
  weekend_posting_allowed: false,
  preferred_times: ['09:00', '14:00'] as const,
  default_timezone: 'America/Chicago',
} as const;

export type AIPostingSettings = typeof AI_POSTING_DEFAULTS;

/**
 * Weekly Posting Limits by Account
 */
export const WEEKLY_LIMITS = {
  ceo_linkedin: {
    // CEO has no strict weekly max, just daily target * days
    // Calculate dynamically: tom_target_posts_per_day * 7
    min: 7, // Minimum 1/day on weekdays + 2 on weekend
    max: 14, // Maximum 2/day every day
  },
  sourceco_linkedin: {
    min: AI_POSTING_DEFAULTS.sourceco_posts_per_week_min,
    max: AI_POSTING_DEFAULTS.sourceco_posts_per_week_max,
  },
  captarget_linkedin: {
    min: AI_POSTING_DEFAULTS.captarget_posts_per_week_min,
    max: AI_POSTING_DEFAULTS.captarget_posts_per_week_max,
  },
} as const;
```

---

## File: packages/shared/src/constants/scheduling.ts

```typescript
/**
 * Scheduling Constants
 * 
 * These define optimal time slots, engagement tiers, and other
 * scheduling-related constants.
 */

/**
 * Maximum messages to include in AI conversation context
 */
export const MAX_CONVERSATION_HISTORY = 10;

/**
 * Time Slot Tiers
 * 
 * Based on LinkedIn engagement data:
 * - Tier 1: Highest engagement (Tuesday/Wednesday mornings)
 * - Tier 2: Good engagement (Thursday/Monday mornings, Tuesday/Wednesday afternoons)
 * - Tier 3: Acceptable engagement (Monday afternoon, Friday morning)
 * - Tier 4 (Avoid): Low engagement (Friday afternoon, weekends)
 */
export const TIME_SLOT_TIERS = {
  TIER_1: [
    { dayOfWeek: 2, hours: [9, 10], label: 'Tuesday 9-10 AM' },
    { dayOfWeek: 3, hours: [9, 10], label: 'Wednesday 9-10 AM' },
    { dayOfWeek: 2, hours: [14], label: 'Tuesday 2 PM' },
    { dayOfWeek: 3, hours: [14], label: 'Wednesday 2 PM' },
  ],
  TIER_2: [
    { dayOfWeek: 4, hours: [9, 10], label: 'Thursday 9-10 AM' },
    { dayOfWeek: 1, hours: [9], label: 'Monday 9 AM' },
    { dayOfWeek: 4, hours: [14, 15], label: 'Thursday 2-3 PM' },
  ],
  TIER_3: [
    { dayOfWeek: 1, hours: [14], label: 'Monday 2 PM' },
    { dayOfWeek: 5, hours: [9], label: 'Friday 9 AM' },
  ],
  TIER_4_AVOID: [
    { dayOfWeek: 5, hours: [12, 13, 14, 15, 16, 17], label: 'Friday afternoon' },
    { dayOfWeek: 0, hours: 'all', label: 'Sunday' },
    { dayOfWeek: 6, hours: 'all', label: 'Saturday' },
  ],
} as const;

/**
 * Content Priority Weights
 * 
 * Higher number = higher priority when scheduling
 */
export const CONTENT_PRIORITY_WEIGHTS = {
  podcast_announcement: 30,
  carousel: 20,
  video: 15,
  text: 10,
  poll: 5,
} as const;

/**
 * Day of Week Constants (for readability)
 */
export const DAY_OF_WEEK = {
  SUNDAY: 0,
  MONDAY: 1,
  TUESDAY: 2,
  WEDNESDAY: 3,
  THURSDAY: 4,
  FRIDAY: 5,
  SATURDAY: 6,
} as const;

/**
 * Optimal posting hours by content type
 */
export const OPTIMAL_HOURS_BY_TYPE = {
  carousel: [9, 10], // Mornings work best for visual content
  video: [10, 11],   // Mid-morning for longer content
  text: [9, 14],     // Flexible
  poll: [10],        // Mid-morning for engagement
  podcast_announcement: [8], // Early morning to catch commuters
} as const;
```

---

## File: packages/shared/src/constants/content.ts

```typescript
/**
 * Content-related constants (types, statuses, etc.)
 */

/**
 * Content Status Enum
 * 
 * Lifecycle: draft → in_review → approved → scheduled → published
 * Can also go to 'failed' from 'scheduled'
 */
export const ContentStatus = {
  DRAFT: 'draft',
  IN_REVIEW: 'in_review',
  APPROVED: 'approved',
  SCHEDULED: 'scheduled',
  PUBLISHED: 'published',
  FAILED: 'failed',
} as const;

export type ContentStatus = typeof ContentStatus[keyof typeof ContentStatus];

/**
 * Content Type Enum
 */
export const ContentType = {
  TEXT: 'text',
  CAROUSEL: 'carousel',
  VIDEO: 'video',
  POLL: 'poll',
  PODCAST_ANNOUNCEMENT: 'podcast_announcement',
  ARTICLE: 'article',
} as const;

export type ContentType = typeof ContentType[keyof typeof ContentType];

/**
 * Target Account (LinkedIn accounts)
 */
export const TargetAccount = {
  CEO_LINKEDIN: 'ceo_linkedin',
  SOURCECO_LINKEDIN: 'sourceco_linkedin',
  CAPTARGET_LINKEDIN: 'captarget_linkedin',
} as const;

export type TargetAccount = typeof TargetAccount[keyof typeof TargetAccount];

/**
 * Readable labels for target accounts
 */
export const TARGET_ACCOUNT_LABELS = {
  [TargetAccount.CEO_LINKEDIN]: 'CEO (Tom)',
  [TargetAccount.SOURCECO_LINKEDIN]: 'SourceCo',
  [TargetAccount.CAPTARGET_LINKEDIN]: 'Captarget',
} as const;

/**
 * Content status transitions (what states can transition to what)
 */
export const ALLOWED_STATUS_TRANSITIONS: Record<ContentStatus, ContentStatus[]> = {
  [ContentStatus.DRAFT]: [ContentStatus.IN_REVIEW, ContentStatus.APPROVED],
  [ContentStatus.IN_REVIEW]: [ContentStatus.DRAFT, ContentStatus.APPROVED],
  [ContentStatus.APPROVED]: [ContentStatus.IN_REVIEW, ContentStatus.SCHEDULED],
  [ContentStatus.SCHEDULED]: [ContentStatus.PUBLISHED, ContentStatus.FAILED],
  [ContentStatus.PUBLISHED]: [],
  [ContentStatus.FAILED]: [ContentStatus.SCHEDULED, ContentStatus.DRAFT],
};

/**
 * Status colors for UI
 */
export const STATUS_COLORS = {
  [ContentStatus.DRAFT]: 'gray',
  [ContentStatus.IN_REVIEW]: 'yellow',
  [ContentStatus.APPROVED]: 'blue',
  [ContentStatus.SCHEDULED]: 'purple',
  [ContentStatus.PUBLISHED]: 'green',
  [ContentStatus.FAILED]: 'red',
} as const;
```

---

## File: packages/shared/src/types/database.ts

```typescript
/**
 * Database Types
 * 
 * Generate these from Supabase:
 * supabase gen types typescript --local > packages/shared/src/types/database.ts
 * 
 * For now, manually defining the core types
 */

export interface Company {
  id: string;
  name: string;
  slug: string;
  timezone: string;
  settings: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface ContentItem {
  id: string;
  company_id: string;
  title: string;
  content: string;
  status: string;
  content_type: string;
  source_content_id: string | null;
  pillar_id: string | null;
  podcast_episode_id: string | null;
  template_id: string | null;
  scheduled_at: string | null;
  published_at: string | null;
  target_account: string;
  owner_id: string;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface QueueItem {
  id: string;
  content_item_id: string;
  queue_id: string;
  content_type: string | null;
  position: number | null;
  scheduled_at: string | null;
  created_at: string;
  deleted_at: string | null;
}

export interface PublishingQueue {
  id: string;
  company_id: string;
  name: string;
  label: string;
  target_account: string;
  max_posts_per_day: number;
  preferred_times: string[];
  created_at: string;
}

export interface PodcastEpisode {
  id: string;
  company_id: string;
  episode_title: string;
  episode_number: number;
  release_date: string;
  guest_name: string | null;
  description: string | null;
  created_at: string;
}

export interface ContentPack {
  id: string;
  source_content_id: string | null; // podcast_episode_id
  pack_type: string;
  generated_at: string;
  created_at: string;
  deleted_at: string | null;
}

export interface AIPostingSettings {
  id: string;
  company_id: string;
  tom_target_posts_per_day: number;
  allow_second_post_tom: boolean;
  min_hours_between_tom_posts: number;
  sourceco_posts_per_week_min: number;
  sourceco_posts_per_week_max: number;
  captarget_posts_per_week_min: number;
  captarget_posts_per_week_max: number;
  min_hours_between_any_posts: number;
  carousel_after_carousel_hours: number;
  video_after_video_hours: number;
  poll_cooldown_hours: number;
  cross_account_same_idea_hours: number;
  weekend_posting_allowed: boolean;
  preferred_times: string[];
  default_timezone: string;
  created_at: string;
  updated_at: string;
}
```

---

## File: packages/shared/src/types/scheduling.ts

```typescript
import { ContentType, TargetAccount } from '../constants/content';

export interface TimeSlot {
  datetime: Date;
  tier: 1 | 2 | 3 | 4;
  score: number;
  reason: string;
}

export interface WeekBounds {
  start: Date;
  end: Date;
  weekNumber: number;
}

export interface ScheduleContext {
  monthStart: Date;
  monthEnd: Date;
  scheduledItems: ScheduledItem[];
  weeklyTotals: Record<string, Record<string, number>>;
  dailyTotals: Record<string, Record<string, number>>;
  getWeeklyCapacity: (weekNum: string, account: string) => number;
  addScheduledItem: (item: ScheduledItem) => void;
}

export interface ScheduledItem {
  id: string;
  title: string;
  content_type: ContentType;
  target_account: TargetAccount;
  source_content_id: string | null;
  pillar_id: string | null;
  podcast_episode_id: string | null;
  scheduledAt: Date;
  slotTier: 1 | 2 | 3 | 4;
  weekNumber: string;
}

export interface DistributionResult {
  scheduledItems: ScheduledItem[];
  warnings: string[];
  blocked: BlockedItem[];
}

export interface BlockedItem {
  item: any;
  reason: string;
}

export interface ValidationResult {
  valid: boolean;
  warnings: string[];
  errors: string[];
  adjustments: Adjustment[];
}

export interface Adjustment {
  item: any;
  originalTime: Date;
  adjustedTime: Date;
  reason: string;
}

export interface PodcastContext {
  episodeId: string;
  releaseDate: Date;
  episodeTitle: string;
  episodeNumber: number;
}

export interface SimilarityResult {
  hasSimilarity: boolean;
  conflicts: Conflict[];
  adjustedTime: Date | null;
}

export interface Conflict {
  item: ScheduledItem;
  reason: string;
  requiredGap: number;
  currentGap: number;
}

export interface SpacingResult {
  allowed: boolean;
  adjustedTime?: Date;
  warning?: string;
}
```

---

## File: packages/shared/src/utils/datetime.ts

```typescript
/**
 * Centralized Date/Time Utilities
 * 
 * All date operations should use these functions to ensure consistency
 */

export class DateTimeUtils {
  constructor(private readonly timezone: string = 'America/Chicago') {}

  /**
   * Convert UTC date to local time in specified timezone
   */
  toLocalTime(utc: Date): Date {
    const localStr = utc.toLocaleString('en-US', {
      timeZone: this.timezone,
    });
    return new Date(localStr);
  }

  /**
   * Convert local time to UTC
   */
  toUTC(localDate: Date, hours: number, minutes: number): Date {
    const dateStr = this.formatDateISO(localDate);
    const timeStr = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00`;
    const localISO = `${dateStr}T${timeStr}`;
    
    // Parse as if it's in the target timezone
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: this.timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
    
    // Create temp date in UTC
    const tempUTC = new Date(`${localISO}Z`);
    
    // Get local time representation
    const localParts = formatter.formatToParts(tempUTC);
    const localTime = new Date(
      parseInt(localParts.find(p => p.type === 'year')!.value),
      parseInt(localParts.find(p => p.type === 'month')!.value) - 1,
      parseInt(localParts.find(p => p.type === 'day')!.value),
      parseInt(localParts.find(p => p.type === 'hour')!.value),
      parseInt(localParts.find(p => p.type === 'minute')!.value),
      parseInt(localParts.find(p => p.type === 'second')!.value)
    );
    
    // Calculate offset
    const offset = tempUTC.getTime() - localTime.getTime();
    
    // Apply offset to get correct UTC time
    const desiredLocal = new Date(`${dateStr}T${hours}:${minutes}:00`);
    return new Date(desiredLocal.getTime() + offset);
  }

  /**
   * Get week bounds (Monday to Sunday, ISO week)
   */
  getWeekBounds(date: Date): { start: Date; end: Date; weekNumber: number } {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1); // Adjust to Monday
    
    const monday = new Date(date);
    monday.setDate(diff);
    monday.setHours(0, 0, 0, 0);
    
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    sunday.setHours(23, 59, 59, 999);
    
    const weekNumber = this.getWeekNumber(date);
    
    return { start: monday, end: sunday, weekNumber };
  }

  /**
   * Get ISO week number
   */
  getWeekNumber(date: Date): number {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  }

  /**
   * Get month bounds
   */
  getMonthBounds(date: Date): { start: Date; end: Date } {
    const start = new Date(date.getFullYear(), date.getMonth(), 1, 0, 0, 0, 0);
    const end = new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59, 999);
    return { start, end };
  }

  /**
   * Format date for display in local timezone
   */
  formatForDisplay(date: Date): string {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: this.timezone,
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(date);
  }

  /**
   * Format date as ISO date string (YYYY-MM-DD)
   */
  formatDateISO(date: Date): string {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: this.timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(date);
  }

  /**
   * Parse schedule time (date + time string)
   */
  parseScheduleTime(dateStr: string, timeStr: string): Date {
    const [hours, minutes] = timeStr.split(':').map(Number);
    const date = new Date(dateStr);
    return this.toUTC(date, hours, minutes);
  }

  /**
   * Check if date is weekend
   */
  isWeekend(date: Date): boolean {
    const day = date.getDay();
    return day === 0 || day === 6;
  }

  /**
   * Check if two dates are on the same day
   */
  isSameDay(date1: Date, date2: Date): boolean {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  }

  /**
   * Get hours difference between two dates
   */
  getHoursDiff(date1: Date, date2: Date): number {
    return Math.abs(date1.getTime() - date2.getTime()) / (1000 * 60 * 60);
  }
}

// Export singleton instance with default timezone
export const dateTimeUtils = new DateTimeUtils();

// Export class for custom timezone instances
export default DateTimeUtils;
```

---

## File: packages/shared/src/index.ts

```typescript
/**
 * Main export file for @marketing-engine/shared package
 */

// Constants
export * from './constants/ai-posting';
export * from './constants/scheduling';
export * from './constants/content';

// Types
export * from './types/database';
export * from './types/scheduling';

// Utils
export * from './utils/datetime';
export { DateTimeUtils } from './utils/datetime';

// Re-export default instance
export { dateTimeUtils as defaultDateTimeUtils } from './utils/datetime';
```

---

## Usage Examples

### In Edge Function:
```typescript
import { AI_POSTING_DEFAULTS, DateTimeUtils } from '@marketing-engine/shared';

const settings = dbSettings || AI_POSTING_DEFAULTS;
const dateUtils = new DateTimeUtils(settings.default_timezone);

const weekBounds = dateUtils.getWeekBounds(new Date());
```

### In Frontend:
```typescript
import { 
  ContentStatus, 
  TargetAccount,
  TARGET_ACCOUNT_LABELS 
} from '@marketing-engine/shared';

const statusLabel = ContentStatus.IN_REVIEW; // 'in_review'
const accountLabel = TARGET_ACCOUNT_LABELS[TargetAccount.CEO_LINKEDIN]; // 'CEO (Tom)'
```

### In Tests:
```typescript
import { AI_POSTING_DEFAULTS, DateTimeUtils } from '@marketing-engine/shared';

describe('Scheduling', () => {
  it('should use default settings', () => {
    expect(AI_POSTING_DEFAULTS.tom_target_posts_per_day).toBe(2);
  });
  
  it('should calculate week bounds correctly', () => {
    const dateUtils = new DateTimeUtils('America/Chicago');
    const bounds = dateUtils.getWeekBounds(new Date('2026-01-20'));
    // assertions...
  });
});
```

---

## Setup Instructions

1. **Create package directory:**
```bash
mkdir -p packages/shared/src/{constants,types,utils,validators}
```

2. **Copy files above into respective locations**

3. **Install dependencies:**
```bash
cd packages/shared
npm install
```

4. **Build:**
```bash
npm run build
```

5. **Link to other packages:**
```bash
# In root package.json:
{
  "workspaces": [
    "apps/*",
    "packages/*"
  ]
}

# In apps/web/package.json:
{
  "dependencies": {
    "@marketing-engine/shared": "workspace:*"
  }
}

# In apps/edge-functions/package.json:
{
  "dependencies": {
    "@marketing-engine/shared": "workspace:*"
  }
}
```

6. **Update imports across codebase:**
```typescript
// BEFORE:
const DEFAULT_TIMEZONE = 'America/Chicago';

// AFTER:
import { AI_POSTING_DEFAULTS } from '@marketing-engine/shared';
const { default_timezone } = AI_POSTING_DEFAULTS;
```

---

## Benefits

✅ **Single Source of Truth:** No more duplicate constants  
✅ **Type Safety:** Shared types across frontend/backend  
✅ **Testable:** Easy to test utilities in isolation  
✅ **Reusable:** Use same logic in multiple places  
✅ **Maintainable:** Update once, changes everywhere
