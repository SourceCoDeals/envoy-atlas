# Multi-Company Architecture Analysis
**Date:** January 21, 2026  
**Question:** Should we simplify SourceCo vs Captarget separation?

---

## 🏢 CURRENT STATE

### How SourceCo/Captarget Are Currently Implemented

**Separate Companies in Database:**
```typescript
companies table:
- id: "38cfc492-f2dc-4c39-9b99-2310d24309e1" (SourceCo)
- id: "9d6c0ee1-4c3d-477d-8070-1a9d822cb19a" (Captarget)

Every table has company_id:
- content_items.company_id
- publishing_queues.company_id
- ai_posting_settings.company_id
- podcast_episodes.company_id
- (and probably more...)
```

**Workspace Filtering:**
```typescript
// Some routes filter by selected workspace
const WORKSPACE_ENABLED_ROUTES = [
  '/dashboard', '/assets', '/audiences', '/queues', '/pipeline'
];

// Other routes don't (/calendar missing!)
// Inconsistent behavior confuses users
```

**Separate LinkedIn Accounts:**
```typescript
publishing_queues:
- ceo_linkedin (Tom's personal account)
- sourceco_linkedin (SourceCo company page)
- captarget_linkedin (Captarget company page)
```

---

## 🤔 BUSINESS REALITY CHECK

### Are They Actually Separate Companies?

**YES - They Are Distinct:**
1. **Legal Structure:** SourceCo is parent, Captarget is subsidiary
2. **Different Offerings:**
   - SourceCo: M&A advisory, deal sourcing
   - Captarget: Data-driven outreach services for PE firms
3. **Different Audiences:**
   - SourceCo: Business owners, private equity
   - Captarget: PE firms seeking acquisition targets
4. **Different Brands:** Separate websites, LinkedIn pages, messaging

**BUT - They Share A LOT:**
1. **Same Team:** You (Tomos) lead both
2. **Same Content Sources:** Podcasts, insights apply to both
3. **Same CEO:** Tom posts about both companies
4. **Shared Resources:** Same tools, same platform, same AI

---

## 🎯 THE REAL QUESTION

### What Problem Are We Trying to Solve?

The multi-company architecture isn't inherently wrong. The problems are:

**❌ Implementation Issues (Current Problems):**
1. Workspace filtering is inconsistent (some pages, not others)
2. Company IDs are hardcoded UUIDs (fragile, unmaintainable)
3. Settings/rules exist at company level causing duplication
4. Switching companies is confusing for users
5. "Which company am I in?" is unclear in UI

**✅ Business Requirements (Must Maintain):**
1. Separate LinkedIn accounts with different posting schedules
2. Separate content libraries (some content is SourceCo-only, some Captarget-only)
3. Separate analytics/reporting
4. Ability to add more brands/subsidiaries in future

---

## 💡 RECOMMENDATION: OPTION 1 - KEEP SEPARATE, FIX IMPLEMENTATION

### Why Keep Them Separate?

1. **Real Business Need:** They ARE different brands
2. **Future Growth:** You might add more subsidiaries
3. **Team Permissions:** Eventually different team members might manage different brands
4. **Clear Separation:** Content/analytics/settings need to be distinct

### What to Fix?

**Phase 1: Structural Improvements (Week 1)**

#### 1.1 Replace UUID Hell with Slugs
```typescript
// BEFORE (Current):
const SOURCECO_ID = "38cfc492-f2dc-4c39-9b99-2310d24309e1";
const CAPTARGET_ID = "9d6c0ee1-4c3d-477d-8070-1a9d822cb19a";

// AFTER:
const company = await getCompanyBySlug('sourceco');
// or
const company = await getCompanyBySlug('captarget');

// Add slug column to companies table
ALTER TABLE companies ADD COLUMN slug TEXT UNIQUE NOT NULL;
UPDATE companies SET slug = 'sourceco' WHERE id = '38cfc492...';
UPDATE companies SET slug = 'captarget' WHERE id = '9d6c0ee1...';
```

**Benefits:**
- No more hardcoded UUIDs
- URLs become `/workspace/sourceco/dashboard` instead of `/workspace/38cfc...`
- Easy to add new companies
- Tests don't break

#### 1.2 Universal Workspace Context
```typescript
// Create a WorkspaceProvider that wraps the entire app
<WorkspaceProvider>
  {/* All routes automatically filter by workspace */}
  <Routes>
    <Route path="/dashboard" element={<Dashboard />} />
    <Route path="/calendar" element={<Calendar />} />
    <Route path="/pipeline" element={<Pipeline />} />
  </Routes>
</WorkspaceProvider>

// Remove WORKSPACE_ENABLED_ROUTES - ALL routes filter by default
// Except explicit exceptions like /settings/profile
```

**Benefits:**
- Consistent behavior across all pages
- No more "which routes have filtering?" confusion
- Workspace is always clear in URL and UI

#### 1.3 Hierarchical Settings
```typescript
// Instead of separate settings per company, use hierarchy:

// Global defaults (entire platform)
const PLATFORM_DEFAULTS = {
  min_hours_between_any_posts: 4,
  weekend_posting_allowed: false,
  // ...
};

// Company-level overrides
ai_posting_settings table:
{
  company_id: 'sourceco-uuid',
  overrides: {
    sourceco_posts_per_week_max: 5,
    preferred_times: ['09:00', '14:00']
  }
}

// Load settings with precedence:
const settings = {
  ...PLATFORM_DEFAULTS,
  ...companySettings.overrides
};
```

**Benefits:**
- DRY - don't repeat defaults for each company
- Clear what's customized vs default
- Easy to update platform-wide defaults

---

**Phase 2: UI Improvements (Week 2)**

#### 2.1 Persistent Workspace Indicator
```typescript
// Always show which workspace you're in:
<Header>
  <WorkspaceBadge>
    <Building2 className="h-4 w-4" />
    <span>{workspace.name}</span> {/* SourceCo or Captarget */}
  </WorkspaceBadge>
  
  <WorkspaceSwitcher>
    <DropdownMenu>
      <option value="sourceco">SourceCo</option>
      <option value="captarget">Captarget</option>
    </DropdownMenu>
  </WorkspaceSwitcher>
</Header>
```

#### 2.2 Workspace-Specific Branding
```typescript
// Each workspace gets its own theme colors
const WORKSPACE_THEMES = {
  sourceco: {
    primary: '#1e40af', // Blue
    logo: '/logos/sourceco.svg'
  },
  captarget: {
    primary: '#059669', // Green
    logo: '/logos/captarget.svg'
  }
};

// Apply theme when workspace changes
<ThemeProvider theme={WORKSPACE_THEMES[workspace.slug]}>
  <App />
</ThemeProvider>
```

#### 2.3 Cross-Workspace Views (When Needed)
```typescript
// Some pages might need to see both companies:
// Example: Your personal dashboard

<Dashboard>
  <Section title="Your Activity Across All Workspaces">
    <WorkspaceTabs>
      <Tab name="SourceCo" data={sourcecoData} />
      <Tab name="Captarget" data={captargetData} />
      <Tab name="Combined" data={combinedData} />
    </WorkspaceTabs>
  </Section>
</Dashboard>
```

---

**Phase 3: Data Layer Optimization (Week 3)**

#### 3.1 Smart Query Utilities
```typescript
// Create utilities that auto-filter by workspace
export function useContentItems() {
  const { workspace } = useWorkspace();
  
  return useQuery({
    queryKey: ['content-items', workspace.id],
    queryFn: () => supabase
      .from('content_items')
      .select('*')
      .eq('company_id', workspace.id)  // Auto-filtered
      .eq('deleted_at', null)
  });
}

// No more forgetting to filter by company!
```

#### 3.2 Database Views Per Company
```sql
-- Create views that are pre-filtered
CREATE VIEW sourceco_content_items AS
SELECT * FROM content_items 
WHERE company_id = (SELECT id FROM companies WHERE slug = 'sourceco')
  AND deleted_at IS NULL;

CREATE VIEW captarget_content_items AS
SELECT * FROM content_items 
WHERE company_id = (SELECT id FROM companies WHERE slug = 'captarget')
  AND deleted_at IS NULL;

-- Queries become simpler and faster
SELECT * FROM sourceco_content_items WHERE status = 'in_review';
```

---

## 🔄 ALTERNATIVE: OPTION 2 - SIMPLIFY TO "BRANDS"

If you want to simplify more aggressively, you could:

```typescript
// Single company, multiple brands
companies table:
- id: "sourceco-parent-id"
- name: "SourceCo Holdings"

brands table:
- id: "brand-sourceco"
- company_id: "sourceco-parent-id"
- name: "SourceCo"
- slug: "sourceco"
- linkedin_page_id: "..."

- id: "brand-captarget"
- company_id: "sourceco-parent-id"  // Same parent
- name: "Captarget"
- slug: "captarget"
- linkedin_page_id: "..."

// All data references brand_id instead of company_id
content_items.brand_id → brands.id
publishing_queues.brand_id → brands.id
```

**Pros:**
- Clearer that they're related
- Shared team/billing/settings at company level
- Brand-specific content/queues
- More accurate to business reality

**Cons:**
- Bigger refactor (change company_id to brand_id everywhere)
- Migration complexity
- Need to decide what lives at company vs brand level

---

## ✅ MY RECOMMENDATION

**Keep companies separate, but fix the implementation (Option 1)**

**Why:**
1. Easier migration path (less breaking changes)
2. Company is a familiar concept
3. Future-proof (can add more companies easily)
4. Matches current database structure

**Implement in this order:**
1. **Week 1:** Add slugs, remove hardcoded UUIDs
2. **Week 2:** Universal workspace context + UI improvements
3. **Week 3:** Query utilities + database optimizations

**This gives you:**
- Clear separation (good for business)
- Clean implementation (good for development)
- Easy to maintain (good for future)
- Consistent UX (good for users)

---

## 🎯 SPECIFIC CHANGES NEEDED

### Change 1: Add Slugs to Companies
```sql
-- Migration
ALTER TABLE companies ADD COLUMN slug TEXT UNIQUE;
ALTER TABLE companies ADD CONSTRAINT companies_slug_check CHECK (slug ~ '^[a-z0-9-]+$');

UPDATE companies SET slug = 'sourceco' 
WHERE id = '38cfc492-f2dc-4c39-9b99-2310d24309e1';

UPDATE companies SET slug = 'captarget' 
WHERE id = '9d6c0ee1-4c3d-477d-8070-1a9d822cb19a';

ALTER TABLE companies ALTER COLUMN slug SET NOT NULL;

-- Add index
CREATE INDEX idx_companies_slug ON companies(slug);
```

### Change 2: Create Workspace Context
```typescript
// src/contexts/WorkspaceContext.tsx
export const WorkspaceProvider: React.FC = ({ children }) => {
  const location = useLocation();
  const [workspaceSlug, setWorkspaceSlug] = useState<string>('sourceco');
  
  // Auto-detect from URL: /workspace/sourceco/dashboard
  useEffect(() => {
    const match = location.pathname.match(/\/workspace\/([^\/]+)/);
    if (match) {
      setWorkspaceSlug(match[1]);
    }
  }, [location]);
  
  const { data: workspace } = useQuery({
    queryKey: ['workspace', workspaceSlug],
    queryFn: () => supabase
      .from('companies')
      .select('*')
      .eq('slug', workspaceSlug)
      .single()
  });
  
  return (
    <WorkspaceContext.Provider value={{ workspace, workspaceSlug, setWorkspaceSlug }}>
      {children}
    </WorkspaceContext.Provider>
  );
};

// Usage anywhere:
const { workspace } = useWorkspace();
console.log(workspace.name); // "SourceCo" or "Captarget"
console.log(workspace.id); // UUID
```

### Change 3: Remove Hardcoded Company IDs
```typescript
// BEFORE (scattered throughout codebase):
const SOURCECO_ID = "38cfc492-f2dc-4c39-9b99-2310d24309e1";
if (companyId === SOURCECO_ID) { ... }

// AFTER:
const { workspace } = useWorkspace();
if (workspace.slug === 'sourceco') { ... }

// Or in edge functions:
const company = await supabase
  .from('companies')
  .select('*')
  .eq('slug', 'sourceco')
  .single();
```

### Change 4: Universal Query Filtering
```typescript
// Create hook that always filters by workspace
export function useWorkspaceQuery<T>(
  tableName: string,
  options?: { select?: string; filter?: any }
) {
  const { workspace } = useWorkspace();
  
  return useQuery({
    queryKey: [tableName, workspace.id, options],
    queryFn: async () => {
      let query = supabase
        .from(tableName)
        .select(options?.select || '*')
        .eq('company_id', workspace.id);
      
      if (options?.filter) {
        query = query.match(options.filter);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as T[];
    },
    enabled: !!workspace
  });
}

// Usage:
const contentItems = useWorkspaceQuery<ContentItem>('content_items', {
  filter: { status: 'in_review' }
});
// Automatically filtered by current workspace!
```

### Change 5: Update Routes
```typescript
// BEFORE:
<Route path="/dashboard" element={<Dashboard />} />
<Route path="/pipeline" element={<Pipeline />} />

// AFTER:
<Route path="/workspace/:workspaceSlug">
  <Route path="dashboard" element={<Dashboard />} />
  <Route path="pipeline" element={<Pipeline />} />
  <Route path="calendar" element={<Calendar />} />
  <Route path="queues" element={<Queues />} />
  {/* All routes auto-filtered by workspace */}
</Route>

// URLs become:
// /workspace/sourceco/dashboard
// /workspace/captarget/calendar
```

---

## 📊 MIGRATION EFFORT

**Phase 1 (Slugs + Basic Workspace):** 2-3 days
- Add slug column to database
- Create WorkspaceProvider
- Update hardcoded company IDs to use slugs
- Test both workspaces

**Phase 2 (UI Improvements):** 2-3 days
- Add workspace indicator to header
- Add workspace switcher
- Apply workspace-specific branding
- Update all routes to use workspace path

**Phase 3 (Query Optimization):** 2-3 days
- Create useWorkspaceQuery hook
- Update all queries to use it
- Create database views (optional)
- Remove old workspace filtering logic

**Total:** 6-9 days for complete migration

---

## ✅ BENEFITS AFTER MIGRATION

**For Development:**
- ✅ No more hardcoded UUIDs
- ✅ Consistent workspace filtering everywhere
- ✅ Easy to add new companies/brands
- ✅ Tests don't break on UUID changes
- ✅ Clear workspace context in every component

**For Users:**
- ✅ Always know which workspace they're in
- ✅ Clean URLs: `/workspace/sourceco/dashboard`
- ✅ Consistent behavior across all pages
- ✅ Easy workspace switching
- ✅ Visual workspace indicator

**For Business:**
- ✅ Maintain separation between brands
- ✅ Can add more subsidiaries easily
- ✅ Supports future team/permission separation
- ✅ Accurate analytics per brand

---

## 🚀 NEXT STEPS

1. **Decide:** Option 1 (keep companies, fix implementation) or Option 2 (brands)?
2. **If Option 1:** Start with Phase 1 (slugs) - lowest risk, high impact
3. **Then:** Continue with original A-E tasks using the improved architecture

Would you like me to:
- Start implementing Phase 1 (slug migration)?
- Or proceed with Option 2 (brands architecture)?
- Or just continue with A-E assuming we'll fix workspace issues later?
