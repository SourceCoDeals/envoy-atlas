# ScheduleCalculator Refactor

Centralized class for all schedule-related calculations to eliminate duplication and inconsistencies.

---

## File: packages/shared/src/services/ScheduleCalculator.ts

```typescript
import {
  AI_POSTING_DEFAULTS,
  TIME_SLOT_TIERS,
  CONTENT_PRIORITY_WEIGHTS,
  DAY_OF_WEEK,
} from '../constants';
import { DateTimeUtils } from '../utils/datetime';
import type {
  AIPostingSettings,
  TargetAccount,
  ContentType,
  TimeSlot,
  WeekBounds,
  ScheduledItem,
} from '../types';

/**
 * ScheduleCalculator
 * 
 * Single source of truth for all scheduling calculations.
 * Use this class in:
 * - Edge functions (actual scheduling)
 * - Frontend (capacity displays, previews)
 * - Analytics (reporting)
 */
export class ScheduleCalculator {
  private dateUtils: DateTimeUtils;

  constructor(
    private settings: AIPostingSettings = AI_POSTING_DEFAULTS,
    timezone?: string
  ) {
    this.dateUtils = new DateTimeUtils(
      timezone || settings.default_timezone || 'America/Chicago'
    );
  }

  // ============================================
  // WEEKLY LIMITS
  // ============================================

  /**
   * Get weekly posting limits for an account
   */
  getWeeklyLimit(account: TargetAccount): { min: number; max: number } {
    switch (account) {
      case 'ceo_linkedin':
        // CEO has no strict weekly max, calculated from daily target
        const dailyTarget = this.settings.tom_target_posts_per_day;
        return {
          min: dailyTarget * 5,  // Weekdays minimum
          max: dailyTarget * 7,  // All days if needed
        };
      
      case 'sourceco_linkedin':
        return {
          min: this.settings.sourceco_posts_per_week_min,
          max: this.settings.sourceco_posts_per_week_max,
        };
      
      case 'captarget_linkedin':
        return {
          min: this.settings.captarget_posts_per_week_min,
          max: this.settings.captarget_posts_per_week_max,
        };
      
      default:
        throw new Error(`Unknown account: ${account}`);
    }
  }

  /**
   * Get daily posting limit for an account
   */
  getDailyLimit(account: TargetAccount, date: Date): number {
    const isWeekend = this.dateUtils.isWeekend(date);
    
    if (!this.settings.weekend_posting_allowed && isWeekend) {
      return 0;
    }

    switch (account) {
      case 'ceo_linkedin':
        return this.settings.allow_second_post_tom
          ? this.settings.tom_target_posts_per_day
          : 1;
      
      case 'sourceco_linkedin':
      case 'captarget_linkedin':
        // For company accounts, distribute weekly max across weekdays
        const weeklyMax = this.getWeeklyLimit(account).max;
        return Math.ceil(weeklyMax / 5); // Typically 1-2 per day
      
      default:
        throw new Error(`Unknown account: ${account}`);
    }
  }

  /**
   * Calculate remaining weekly capacity for an account
   */
  calculateWeeklyCapacity(
    account: TargetAccount,
    weekBounds: WeekBounds,
    existingScheduled: ScheduledItem[]
  ): number {
    const limit = this.getWeeklyLimit(account);
    
    // Count posts already scheduled this week for this account
    const scheduledThisWeek = existingScheduled.filter(item =>
      item.target_account === account &&
      item.scheduledAt >= weekBounds.start &&
      item.scheduledAt <= weekBounds.end
    ).length;

    return limit.max - scheduledThisWeek;
  }

  /**
   * Calculate remaining daily capacity for an account
   */
  calculateDailyCapacity(
    account: TargetAccount,
    date: Date,
    existingScheduled: ScheduledItem[]
  ): number {
    const limit = this.getDailyLimit(account, date);
    
    // Count posts already scheduled on this day for this account
    const scheduledToday = existingScheduled.filter(item =>
      item.target_account === account &&
      this.dateUtils.isSameDay(item.scheduledAt, date)
    ).length;

    return limit - scheduledToday;
  }

  // ============================================
  // TIME SLOT SELECTION
  // ============================================

  /**
   * Get optimal time slots for a given date
   */
  getOptimalSlots(date: Date, account: TargetAccount): TimeSlot[] {
    const dayOfWeek = date.getDay();
    const slots: TimeSlot[] = [];

    // Check Tier 1 slots
    TIME_SLOT_TIERS.TIER_1.forEach(tier => {
      if (tier.dayOfWeek === dayOfWeek) {
        tier.hours.forEach(hour => {
          slots.push({
            datetime: this.createDateTimeSlot(date, hour, 0),
            tier: 1,
            score: 100,
            reason: `Tier 1: ${tier.label}`,
          });
        });
      }
    });

    // Check Tier 2 slots
    TIME_SLOT_TIERS.TIER_2.forEach(tier => {
      if (tier.dayOfWeek === dayOfWeek) {
        tier.hours.forEach(hour => {
          slots.push({
            datetime: this.createDateTimeSlot(date, hour, 0),
            tier: 2,
            score: 70,
            reason: `Tier 2: ${tier.label}`,
          });
        });
      }
    });

    // Check Tier 3 slots
    TIME_SLOT_TIERS.TIER_3.forEach(tier => {
      if (tier.dayOfWeek === dayOfWeek) {
        tier.hours.forEach(hour => {
          slots.push({
            datetime: this.createDateTimeSlot(date, hour, 0),
            tier: 3,
            score: 40,
            reason: `Tier 3: ${tier.label}`,
          });
        });
      }
    });

    // Add preferred times from settings
    this.settings.preferred_times.forEach(timeStr => {
      const [hours, minutes] = timeStr.split(':').map(Number);
      const datetime = this.createDateTimeSlot(date, hours, minutes);
      
      // Check if this slot already exists in tiers
      const exists = slots.some(s =>
        s.datetime.getTime() === datetime.getTime()
      );
      
      if (!exists) {
        slots.push({
          datetime,
          tier: 2, // Preferred times are Tier 2
          score: 65,
          reason: 'Preferred time from settings',
        });
      }
    });

    return slots.sort((a, b) => b.score - a.score);
  }

  /**
   * Calculate slot score based on content type and other factors
   */
  calculateSlotScore(
    slot: TimeSlot,
    contentType: ContentType,
    existingScheduled: ScheduledItem[]
  ): number {
    let score = slot.score;

    // Boost for content type preferences
    const hour = slot.datetime.getHours();
    switch (contentType) {
      case 'carousel':
        // Carousels work best in morning
        if (hour >= 9 && hour <= 10) score += 15;
        break;
      case 'video':
        // Videos work best mid-morning
        if (hour >= 10 && hour <= 11) score += 10;
        break;
      case 'podcast_announcement':
        // Early morning for commuters
        if (hour === 8) score += 20;
        break;
    }

    // Penalize if too close to existing posts
    const tooClose = existingScheduled.some(item => {
      const hoursDiff = this.dateUtils.getHoursDiff(
        slot.datetime,
        item.scheduledAt
      );
      return hoursDiff < this.settings.min_hours_between_any_posts;
    });
    
    if (tooClose) score -= 30;

    return Math.max(0, score);
  }

  /**
   * Find best available slot for content
   */
  findBestSlot(
    date: Date,
    account: TargetAccount,
    contentType: ContentType,
    existingScheduled: ScheduledItem[]
  ): TimeSlot | null {
    const candidates = this.getOptimalSlots(date, account);

    // Score each candidate
    const scoredSlots = candidates
      .map(slot => ({
        ...slot,
        score: this.calculateSlotScore(slot, contentType, existingScheduled),
      }))
      .filter(slot => slot.score > 0)
      .sort((a, b) => b.score - a.score);

    return scoredSlots[0] || null;
  }

  // ============================================
  // CONTENT SPACING VALIDATION
  // ============================================

  /**
   * Validate content type spacing (carousel → carousel, etc.)
   */
  validateContentTypeSpacing(
    contentType: ContentType,
    proposedTime: Date,
    account: TargetAccount,
    existingScheduled: ScheduledItem[]
  ): { valid: boolean; adjustedTime?: Date; warning?: string } {
    // Get last post of same type on same account
    const sameTypeItems = existingScheduled
      .filter(item =>
        item.target_account === account &&
        item.content_type === contentType
      )
      .sort((a, b) => b.scheduledAt.getTime() - a.scheduledAt.getTime());

    if (sameTypeItems.length === 0) {
      return { valid: true };
    }

    const lastSameType = sameTypeItems[0];
    const hoursDiff = this.dateUtils.getHoursDiff(
      proposedTime,
      lastSameType.scheduledAt
    );

    // Get required spacing for this content type
    let requiredHours = this.settings.min_hours_between_any_posts;
    switch (contentType) {
      case 'carousel':
        requiredHours = this.settings.carousel_after_carousel_hours;
        break;
      case 'video':
        requiredHours = this.settings.video_after_video_hours;
        break;
      case 'poll':
        requiredHours = this.settings.poll_cooldown_hours;
        break;
    }

    if (hoursDiff < requiredHours) {
      const adjustedTime = new Date(
        lastSameType.scheduledAt.getTime() + requiredHours * 3600000
      );
      
      return {
        valid: false,
        adjustedTime,
        warning: `${contentType} needs ${requiredHours}hr gap from last ${contentType}. Moved to ${this.dateUtils.formatForDisplay(adjustedTime)}`,
      };
    }

    return { valid: true };
  }

  /**
   * Validate same-source content spacing
   */
  validateSourceContentSpacing(
    sourceContentId: string,
    proposedTime: Date,
    account: TargetAccount,
    existingScheduled: ScheduledItem[]
  ): { valid: boolean; adjustedTime?: Date; warning?: string } {
    const sameSourceItems = existingScheduled.filter(
      item =>
        item.source_content_id === sourceContentId &&
        item.target_account === account
    );

    if (sameSourceItems.length === 0) {
      return { valid: true };
    }

    // Check minimum gap (72 hours for same account)
    const requiredHours = this.settings.same_source_same_account_hours || 72;
    
    for (const existing of sameSourceItems) {
      const hoursDiff = this.dateUtils.getHoursDiff(
        proposedTime,
        existing.scheduledAt
      );
      
      if (hoursDiff < requiredHours) {
        const adjustedTime = new Date(
          existing.scheduledAt.getTime() + requiredHours * 3600000
        );
        
        return {
          valid: false,
          adjustedTime,
          warning: `Same source content needs ${requiredHours}hr gap. Moved to ${this.dateUtils.formatForDisplay(adjustedTime)}`,
        };
      }
    }

    return { valid: true };
  }

  /**
   * Validate cross-account spacing for same content
   */
  validateCrossAccountSpacing(
    sourceContentId: string,
    proposedTime: Date,
    account: TargetAccount,
    existingScheduled: ScheduledItem[]
  ): { valid: boolean; adjustedTime?: Date; warning?: string } {
    const sameSourceOtherAccounts = existingScheduled.filter(
      item =>
        item.source_content_id === sourceContentId &&
        item.target_account !== account
    );

    if (sameSourceOtherAccounts.length === 0) {
      return { valid: true };
    }

    const requiredHours = this.settings.cross_account_same_idea_hours || 36;
    
    for (const existing of sameSourceOtherAccounts) {
      const hoursDiff = this.dateUtils.getHoursDiff(
        proposedTime,
        existing.scheduledAt
      );
      
      if (hoursDiff < requiredHours) {
        const adjustedTime = new Date(
          existing.scheduledAt.getTime() + requiredHours * 3600000
        );
        
        return {
          valid: false,
          adjustedTime,
          warning: `Cross-account same content needs ${requiredHours}hr gap. Moved to ${this.dateUtils.formatForDisplay(adjustedTime)}`,
        };
      }
    }

    return { valid: true };
  }

  // ============================================
  // DISTRIBUTION HELPERS
  // ============================================

  /**
   * Calculate priority score for content
   */
  calculatePriorityScore(
    contentType: ContentType,
    isPodcast: boolean = false
  ): number {
    let score = CONTENT_PRIORITY_WEIGHTS[contentType] || 10;
    
    // Boost podcast content
    if (isPodcast) score += 10;
    
    return score;
  }

  /**
   * Get week bounds for a date
   */
  getWeekBounds(date: Date): WeekBounds {
    return this.dateUtils.getWeekBounds(date);
  }

  /**
   * Get month bounds for a date
   */
  getMonthBounds(date: Date): { start: Date; end: Date } {
    return this.dateUtils.getMonthBounds(date);
  }

  /**
   * Check if weekend posting is allowed
   */
  isWeekendAllowed(): boolean {
    return this.settings.weekend_posting_allowed;
  }

  /**
   * Check if a date is a weekend
   */
  isWeekend(date: Date): boolean {
    return this.dateUtils.isWeekend(date);
  }

  // ============================================
  // HELPER METHODS
  // ============================================

  private createDateTimeSlot(date: Date, hours: number, minutes: number): Date {
    return this.dateUtils.toUTC(date, hours, minutes);
  }
}

// Export singleton instance with defaults
export const defaultScheduleCalculator = new ScheduleCalculator();
```

---

## Usage Examples

### In Edge Function:

```typescript
import { ScheduleCalculator } from '@marketing-engine/shared/services';
import { AIPostingSettings } from '@marketing-engine/shared/types';

// Initialize with settings from DB
const calculator = new ScheduleCalculator(dbSettings);

// Get weekly capacity
const weekBounds = calculator.getWeekBounds(new Date());
const capacity = calculator.calculateWeeklyCapacity(
  'sourceco_linkedin',
  weekBounds,
  existingSchedule
);

console.log(`SourceCo has ${capacity} slots remaining this week`);

// Find best slot
const bestSlot = calculator.findBestSlot(
  new Date(),
  'ceo_linkedin',
  'carousel',
  existingSchedule
);

if (bestSlot) {
  console.log(`Best slot: ${bestSlot.datetime} (Tier ${bestSlot.tier})`);
}

// Validate spacing
const spacingCheck = calculator.validateContentTypeSpacing(
  'carousel',
  proposedTime,
  'sourceco_linkedin',
  existingSchedule
);

if (!spacingCheck.valid) {
  console.log(`Warning: ${spacingCheck.warning}`);
  // Use spacingCheck.adjustedTime
}
```

### In Frontend (Capacity Display):

```typescript
import { ScheduleCalculator } from '@marketing-engine/shared/services';
import { useAIPostingSettings } from '@/hooks/useAIPostingSettings';
import { useScheduledContent } from '@/hooks/useScheduledContent';

function CapacityWidget() {
  const { settings } = useAIPostingSettings();
  const { scheduledItems } = useScheduledContent();
  
  const calculator = new ScheduleCalculator(settings);
  const weekBounds = calculator.getWeekBounds(new Date());
  
  const accounts: TargetAccount[] = [
    'ceo_linkedin',
    'sourceco_linkedin',
    'captarget_linkedin',
  ];
  
  return (
    <div className="space-y-2">
      <h3 className="font-semibold">Weekly Capacity</h3>
      {accounts.map(account => {
        const capacity = calculator.calculateWeeklyCapacity(
          account,
          weekBounds,
          scheduledItems
        );
        const limit = calculator.getWeeklyLimit(account);
        
        return (
          <div key={account} className="flex items-center justify-between">
            <span>{account}</span>
            <span className="text-sm text-gray-600">
              {limit.max - capacity}/{limit.max} used
            </span>
          </div>
        );
      })}
    </div>
  );
}
```

### In Tests:

```typescript
import { ScheduleCalculator } from '@marketing-engine/shared/services';
import { AI_POSTING_DEFAULTS } from '@marketing-engine/shared/constants';

describe('ScheduleCalculator', () => {
  it('should calculate weekly limits correctly', () => {
    const calculator = new ScheduleCalculator(AI_POSTING_DEFAULTS);
    
    const ceoLimit = calculator.getWeeklyLimit('ceo_linkedin');
    expect(ceoLimit.min).toBe(7); // 1/day on weekdays + 2 on weekend
    expect(ceoLimit.max).toBe(14); // 2/day every day
    
    const sourcecoLimit = calculator.getWeeklyLimit('sourceco_linkedin');
    expect(sourcecoLimit.min).toBe(3);
    expect(sourcecoLimit.max).toBe(5);
  });
  
  it('should find best time slot', () => {
    const calculator = new ScheduleCalculator(AI_POSTING_DEFAULTS);
    
    // Tuesday morning should be Tier 1
    const tuesday = new Date('2026-01-21T12:00:00Z'); // Tuesday
    const bestSlot = calculator.findBestSlot(
      tuesday,
      'ceo_linkedin',
      'carousel',
      []
    );
    
    expect(bestSlot).toBeDefined();
    expect(bestSlot?.tier).toBe(1);
    expect(bestSlot?.datetime.getHours()).toBeGreaterThanOrEqual(9);
    expect(bestSlot?.datetime.getHours()).toBeLessThanOrEqual(10);
  });
  
  it('should validate content spacing', () => {
    const calculator = new ScheduleCalculator(AI_POSTING_DEFAULTS);
    
    const existingCarousel: ScheduledItem = {
      id: '1',
      title: 'Test',
      content_type: 'carousel',
      target_account: 'sourceco_linkedin',
      source_content_id: null,
      pillar_id: null,
      podcast_episode_id: null,
      scheduledAt: new Date('2026-01-21T09:00:00Z'),
      slotTier: 1,
      weekNumber: '3',
    };
    
    // Try to schedule another carousel 2 hours later (should fail, needs 24hr)
    const proposedTime = new Date('2026-01-21T11:00:00Z');
    
    const validation = calculator.validateContentTypeSpacing(
      'carousel',
      proposedTime,
      'sourceco_linkedin',
      [existingCarousel]
    );
    
    expect(validation.valid).toBe(false);
    expect(validation.adjustedTime).toBeDefined();
    expect(validation.warning).toContain('24hr gap');
  });
});
```

---

## Benefits

✅ **Single Source of Truth:** All scheduling logic in one place  
✅ **Consistent Behavior:** Frontend and backend use same calculations  
✅ **Testable:** Easy to test in isolation  
✅ **Type-Safe:** Full TypeScript support  
✅ **Maintainable:** Update once, changes everywhere  
✅ **Reusable:** Use in edge functions, frontend, tests, analytics

---

## Migration Strategy

1. **Create the ScheduleCalculator class** in shared package
2. **Update edge function** to use calculator instead of inline logic
3. **Update frontend hooks** to use calculator for capacity displays
4. **Add tests** for all calculator methods
5. **Remove old calculation code** once migration complete

**Estimated Effort:** 1-2 days  
**Impact:** Eliminates calculation inconsistencies, makes testing possible
