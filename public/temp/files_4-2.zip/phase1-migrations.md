# Phase 1: Data Integrity Migration Scripts

## Migration 001: Add Company Slugs
**File:** `supabase/migrations/20260121_001_add_company_slugs.sql`

```sql
-- Add slug column to companies
ALTER TABLE companies 
ADD COLUMN slug TEXT,
ADD COLUMN timezone TEXT DEFAULT 'America/Chicago',
ADD COLUMN settings JSONB DEFAULT '{}'::jsonb;

-- Add constraint for slug format (lowercase, alphanumeric, hyphens only)
ALTER TABLE companies 
ADD CONSTRAINT companies_slug_format 
CHECK (slug ~ '^[a-z0-9-]+$');

-- Populate slugs for existing companies
UPDATE companies 
SET slug = 'sourceco' 
WHERE id = '38cfc492-f2dc-4c39-9b99-2310d24309e1';

UPDATE companies 
SET slug = 'captarget' 
WHERE id = '9d6c0ee1-4c3d-477d-8070-1a9d822cb19a';

-- Make slug required and unique
ALTER TABLE companies 
ALTER COLUMN slug SET NOT NULL,
ADD CONSTRAINT companies_slug_unique UNIQUE (slug);

-- Create index for fast slug lookups
CREATE INDEX idx_companies_slug ON companies(slug);

-- Add helpful function to get company by slug
CREATE OR REPLACE FUNCTION get_company_by_slug(company_slug TEXT)
RETURNS TABLE (
  id UUID,
  name TEXT,
  slug TEXT,
  timezone TEXT,
  settings JSONB,
  created_at TIMESTAMP
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    c.id,
    c.name,
    c.slug,
    c.timezone,
    c.settings,
    c.created_at
  FROM companies c
  WHERE c.slug = company_slug;
END;
$$ LANGUAGE plpgsql;
```

---

## Migration 002: Add Foreign Key Constraints
**File:** `supabase/migrations/20260121_002_add_foreign_keys.sql`

```sql
-- ============================================
-- Add Foreign Key Constraints
-- ============================================

-- content_items → content_packs
ALTER TABLE content_items
ADD CONSTRAINT fk_content_items_content_pack
FOREIGN KEY (source_content_id) 
REFERENCES content_packs(id)
ON DELETE SET NULL;

-- content_items → companies
ALTER TABLE content_items
ADD CONSTRAINT fk_content_items_company
FOREIGN KEY (company_id)
REFERENCES companies(id)
ON DELETE CASCADE;

-- content_items → profiles (owner)
ALTER TABLE content_items
ADD CONSTRAINT fk_content_items_owner
FOREIGN KEY (owner_id)
REFERENCES profiles(id)
ON DELETE SET NULL;

-- content_packs → podcast_episodes
ALTER TABLE content_packs
ADD CONSTRAINT fk_content_packs_episode
FOREIGN KEY (source_content_id)
REFERENCES podcast_episodes(id)
ON DELETE SET NULL;

-- queue_items → content_items
ALTER TABLE queue_items
ADD CONSTRAINT fk_queue_items_content
FOREIGN KEY (content_item_id)
REFERENCES content_items(id)
ON DELETE CASCADE;  -- If content deleted, remove from queue

-- queue_items → publishing_queues
ALTER TABLE queue_items
ADD CONSTRAINT fk_queue_items_queue
FOREIGN KEY (queue_id)
REFERENCES publishing_queues(id)
ON DELETE CASCADE;

-- publishing_queues → companies
ALTER TABLE publishing_queues
ADD CONSTRAINT fk_queues_company
FOREIGN KEY (company_id)
REFERENCES companies(id)
ON DELETE CASCADE;

-- ai_posting_settings → companies
ALTER TABLE ai_posting_settings
ADD CONSTRAINT fk_settings_company
FOREIGN KEY (company_id)
REFERENCES companies(id)
ON DELETE CASCADE;

-- podcast_episodes → companies
ALTER TABLE podcast_episodes
ADD CONSTRAINT fk_episodes_company
FOREIGN KEY (company_id)
REFERENCES companies(id)
ON DELETE CASCADE;

COMMENT ON CONSTRAINT fk_content_items_content_pack ON content_items IS 
'Content items are generated from content packs. SET NULL allows orphaned content.';

COMMENT ON CONSTRAINT fk_queue_items_content ON queue_items IS 
'Queue items are temporary - cascade delete if content is removed.';
```

---

## Migration 003: Add Uniqueness Constraints
**File:** `supabase/migrations/20260121_003_add_unique_constraints.sql`

```sql
-- ============================================
-- Add Uniqueness Constraints
-- ============================================

-- Prevent same content from being added to queue twice
ALTER TABLE queue_items
ADD CONSTRAINT unique_content_in_queue
UNIQUE (content_item_id, queue_id);

-- Prevent duplicate content packs for same episode
-- (Allow multiple packs if pack_type differs)
ALTER TABLE content_packs
ADD CONSTRAINT unique_pack_per_episode_type
UNIQUE (source_content_id, pack_type);

-- Prevent scheduling two posts at exact same time on same account
-- (Partial unique index - only applies to scheduled content)
CREATE UNIQUE INDEX unique_scheduled_slot
ON content_items (company_id, target_account, scheduled_at)
WHERE status = 'scheduled' AND deleted_at IS NULL;

-- Ensure queue names are unique per company
ALTER TABLE publishing_queues
ADD CONSTRAINT unique_queue_name_per_company
UNIQUE (company_id, name);

COMMENT ON CONSTRAINT unique_content_in_queue ON queue_items IS
'Prevents accidentally adding the same content to a queue multiple times.';

COMMENT ON INDEX unique_scheduled_slot IS
'Prevents double-booking: one post per account per time slot.';
```

---

## Migration 004: Standardize Soft Delete Pattern
**File:** `supabase/migrations/20260121_004_soft_delete_views.sql`

```sql
-- ============================================
-- Standardize Soft Delete with Views
-- ============================================

-- Create views that auto-filter deleted items
CREATE VIEW active_content_items AS
SELECT * FROM content_items 
WHERE deleted_at IS NULL;

CREATE VIEW active_content_packs AS
SELECT * FROM content_packs
WHERE deleted_at IS NULL;

CREATE VIEW active_queue_items AS
SELECT * FROM queue_items
WHERE deleted_at IS NULL;

-- Create helper function to soft delete
CREATE OR REPLACE FUNCTION soft_delete_content_item(item_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE content_items 
  SET deleted_at = NOW()
  WHERE id = item_id;
END;
$$ LANGUAGE plpgsql;

-- Create helper function to restore
CREATE OR REPLACE FUNCTION restore_content_item(item_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE content_items 
  SET deleted_at = NULL
  WHERE id = item_id;
END;
$$ LANGUAGE plpgsql;

-- Grant permissions on views
GRANT SELECT ON active_content_items TO authenticated;
GRANT SELECT ON active_content_packs TO authenticated;
GRANT SELECT ON active_queue_items TO authenticated;

COMMENT ON VIEW active_content_items IS
'View that excludes soft-deleted items. Use this instead of content_items table in queries.';
```

---

## Migration 005: Add Critical Indexes
**File:** `supabase/migrations/20260121_005_add_indexes.sql`

```sql
-- ============================================
-- Add Performance Indexes
-- ============================================

-- Content items - Most queried fields
CREATE INDEX idx_content_items_company_status 
ON content_items(company_id, status) 
WHERE deleted_at IS NULL;

CREATE INDEX idx_content_items_scheduled 
ON content_items(scheduled_at, status)
WHERE deleted_at IS NULL AND scheduled_at IS NOT NULL;

CREATE INDEX idx_content_items_source 
ON content_items(source_content_id)
WHERE source_content_id IS NOT NULL;

CREATE INDEX idx_content_items_owner 
ON content_items(owner_id, status)
WHERE deleted_at IS NULL;

-- Queue items - Fast queue lookups
CREATE INDEX idx_queue_items_queue 
ON queue_items(queue_id);

CREATE INDEX idx_queue_items_content 
ON queue_items(content_item_id);

CREATE INDEX idx_queue_items_scheduled 
ON queue_items(scheduled_at)
WHERE scheduled_at IS NOT NULL;

-- Content packs - Episode lookups
CREATE INDEX idx_content_packs_episode 
ON content_packs(source_content_id)
WHERE source_content_id IS NOT NULL;

-- Publishing queues - Company lookups
CREATE INDEX idx_queues_company 
ON publishing_queues(company_id);

-- Podcast episodes - Company and date filtering
CREATE INDEX idx_episodes_company_date 
ON podcast_episodes(company_id, release_date);

COMMENT ON INDEX idx_content_items_company_status IS
'Optimizes common query: get content by company and status (e.g., all in_review items)';

COMMENT ON INDEX idx_content_items_scheduled IS
'Optimizes calendar queries: get all scheduled content within date range';
```

---

## Migration 006: Separate Templates from Content
**File:** `supabase/migrations/20260121_006_separate_templates.sql`

```sql
-- ============================================
-- Separate Templates into Own Table
-- ============================================

-- Create new content_templates table
CREATE TABLE content_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT,
  template_type TEXT NOT NULL,
  category TEXT,
  variables JSONB DEFAULT '[]'::jsonb,
  usage_count INTEGER DEFAULT 0,
  created_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Add indexes
CREATE INDEX idx_templates_company ON content_templates(company_id);
CREATE INDEX idx_templates_type ON content_templates(template_type);

-- Migrate existing templates from content_items
INSERT INTO content_templates (
  id, company_id, title, content, template_type, created_at
)
SELECT 
  id,
  company_id,
  title,
  content,
  'linkedin_post' as template_type,
  created_at
FROM content_items
WHERE status = 'source';

-- Add template_id to content_items
ALTER TABLE content_items
ADD COLUMN template_id UUID REFERENCES content_templates(id) ON DELETE SET NULL;

-- Update content items to reference templates
UPDATE content_items ci
SET template_id = ci.id
WHERE ci.status = 'source';

-- Soft delete template content items (they're now in content_templates)
UPDATE content_items
SET deleted_at = NOW()
WHERE status = 'source';

-- Add check constraint to prevent templates in content_items
ALTER TABLE content_items
ADD CONSTRAINT no_template_status
CHECK (status != 'source');

COMMENT ON TABLE content_templates IS
'Templates for generating content. Separated from actual content items for clarity.';

COMMENT ON COLUMN content_items.template_id IS
'Optional reference to the template this content was generated from.';
```

---

## Migration 007: Create Content Status Audit Trail
**File:** `supabase/migrations/20260121_007_status_audit_trail.sql`

```sql
-- ============================================
-- Add Status Change Audit Trail
-- ============================================

-- Create enum for content status
CREATE TYPE content_status AS ENUM (
  'draft',
  'in_review', 
  'approved',
  'scheduled',
  'published',
  'failed'
);

-- Update content_items to use enum (after migrating existing data)
-- First, ensure all statuses match enum values
UPDATE content_items 
SET status = 'draft' 
WHERE status NOT IN ('draft', 'in_review', 'approved', 'scheduled', 'published', 'failed', 'source');

-- Create audit table
CREATE TABLE content_status_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_item_id UUID NOT NULL REFERENCES content_items(id) ON DELETE CASCADE,
  from_status TEXT,
  to_status TEXT NOT NULL,
  changed_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
  changed_at TIMESTAMP DEFAULT NOW(),
  reason TEXT,
  metadata JSONB DEFAULT '{}'::jsonb
);

-- Add index for fast lookups
CREATE INDEX idx_status_history_content ON content_status_history(content_item_id, changed_at DESC);
CREATE INDEX idx_status_history_user ON content_status_history(changed_by);

-- Create trigger to auto-log status changes
CREATE OR REPLACE FUNCTION log_content_status_change()
RETURNS TRIGGER AS $$
BEGIN
  IF (TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status) THEN
    INSERT INTO content_status_history (
      content_item_id,
      from_status,
      to_status,
      changed_by
    ) VALUES (
      NEW.id,
      OLD.status,
      NEW.status,
      auth.uid()  -- Current user from Supabase Auth
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER content_status_change_trigger
AFTER UPDATE ON content_items
FOR EACH ROW
EXECUTE FUNCTION log_content_status_change();

COMMENT ON TABLE content_status_history IS
'Audit trail of all content status changes. Auto-populated by trigger.';
```

---

## Migration 008: Initialize AI Posting Settings
**File:** `supabase/migrations/20260121_008_init_ai_settings.sql`

```sql
-- ============================================
-- Initialize AI Posting Settings for All Companies
-- ============================================

-- Ensure all companies have default settings
INSERT INTO ai_posting_settings (
  company_id,
  tom_target_posts_per_day,
  allow_second_post_tom,
  min_hours_between_tom_posts,
  sourceco_posts_per_week_min,
  sourceco_posts_per_week_max,
  captarget_posts_per_week_min,
  captarget_posts_per_week_max,
  min_hours_between_any_posts,
  carousel_after_carousel_hours,
  video_after_video_hours,
  poll_cooldown_hours,
  cross_account_same_idea_hours,
  weekend_posting_allowed,
  preferred_times,
  default_timezone
)
SELECT 
  id as company_id,
  2,      -- tom_target_posts_per_day
  true,   -- allow_second_post_tom
  6,      -- min_hours_between_tom_posts
  3,      -- sourceco_posts_per_week_min
  5,      -- sourceco_posts_per_week_max
  3,      -- captarget_posts_per_week_min
  5,      -- captarget_posts_per_week_max
  4,      -- min_hours_between_any_posts
  24,     -- carousel_after_carousel_hours
  24,     -- video_after_video_hours
  72,     -- poll_cooldown_hours
  36,     -- cross_account_same_idea_hours
  false,  -- weekend_posting_allowed
  ARRAY['09:00', '14:00'],  -- preferred_times
  'America/Chicago'  -- default_timezone
FROM companies
WHERE NOT EXISTS (
  SELECT 1 FROM ai_posting_settings 
  WHERE ai_posting_settings.company_id = companies.id
);

COMMENT ON TABLE ai_posting_settings IS
'AI posting rules and preferences per company. Initialized with sensible defaults.';
```

---

## Migration 009: Add Content Metadata Fields
**File:** `supabase/migrations/20260121_009_content_metadata.sql`

```sql
-- ============================================
-- Add Missing Metadata to Queue Items
-- ============================================

-- Ensure content_type exists on queue_items
-- (Already added in earlier migration, but including for completeness)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'queue_items' AND column_name = 'content_type'
  ) THEN
    ALTER TABLE queue_items ADD COLUMN content_type TEXT;
  END IF;
END $$;

-- Add function to sync metadata from content_items when adding to queue
CREATE OR REPLACE FUNCTION sync_queue_item_metadata()
RETURNS TRIGGER AS $$
BEGIN
  -- Sync content_type from content_items
  SELECT content_type INTO NEW.content_type
  FROM content_items
  WHERE id = NEW.content_item_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sync_queue_metadata_trigger
BEFORE INSERT ON queue_items
FOR EACH ROW
EXECUTE FUNCTION sync_queue_item_metadata();

-- Add denormalized episode_id to content_items for easier querying
ALTER TABLE content_items
ADD COLUMN podcast_episode_id UUID REFERENCES podcast_episodes(id) ON DELETE SET NULL;

-- Populate episode_id for existing content
UPDATE content_items ci
SET podcast_episode_id = cp.source_content_id
FROM content_packs cp
WHERE ci.source_content_id = cp.id
  AND cp.source_content_id IS NOT NULL;

-- Create index
CREATE INDEX idx_content_episode ON content_items(podcast_episode_id)
WHERE podcast_episode_id IS NOT NULL;

COMMENT ON COLUMN content_items.podcast_episode_id IS
'Denormalized episode ID for fast podcast content queries. Eliminates 3-hop join.';
```

---

## Migration 010: Create Helpful Views
**File:** `supabase/migrations/20260121_010_helpful_views.sql`

```sql
-- ============================================
-- Create Views for Common Queries
-- ============================================

-- View: Content with owner and episode info
CREATE VIEW content_items_enriched AS
SELECT 
  ci.*,
  p.name as owner_name,
  p.email as owner_email,
  pe.episode_title,
  pe.release_date as episode_release_date,
  pe.episode_number,
  cp.pack_type as content_pack_type,
  c.name as company_name,
  c.slug as company_slug
FROM content_items ci
LEFT JOIN profiles p ON ci.owner_id = p.id
LEFT JOIN podcast_episodes pe ON ci.podcast_episode_id = pe.id
LEFT JOIN content_packs cp ON ci.source_content_id = cp.id
LEFT JOIN companies c ON ci.company_id = c.id
WHERE ci.deleted_at IS NULL;

-- View: Queue with full content details
CREATE VIEW queue_items_with_content AS
SELECT 
  qi.*,
  ci.title as content_title,
  ci.content as content_text,
  ci.status as content_status,
  ci.content_type,
  ci.target_account,
  ci.podcast_episode_id,
  pq.name as queue_name,
  pq.company_id,
  c.slug as company_slug
FROM queue_items qi
JOIN content_items ci ON qi.content_item_id = ci.id
JOIN publishing_queues pq ON qi.queue_id = pq.id
JOIN companies c ON pq.company_id = c.id
WHERE qi.deleted_at IS NULL 
  AND ci.deleted_at IS NULL
  AND qi.scheduled_at IS NULL;  -- Only unscheduled items in queue

-- View: Scheduled content calendar
CREATE VIEW content_calendar AS
SELECT
  ci.id,
  ci.title,
  ci.scheduled_at,
  ci.target_account,
  ci.content_type,
  ci.status,
  pe.episode_title,
  c.name as company_name,
  c.slug as company_slug,
  p.name as owner_name
FROM content_items ci
LEFT JOIN podcast_episodes pe ON ci.podcast_episode_id = pe.id
JOIN companies c ON ci.company_id = c.id
LEFT JOIN profiles p ON ci.owner_id = p.id
WHERE ci.deleted_at IS NULL
  AND ci.scheduled_at IS NOT NULL
  AND ci.status IN ('scheduled', 'published')
ORDER BY ci.scheduled_at ASC;

-- View: Content with podcast context (for release date validation)
CREATE VIEW content_with_podcast_context AS
SELECT
  ci.id,
  ci.title,
  ci.scheduled_at,
  ci.status,
  pe.id as episode_id,
  pe.episode_title,
  pe.release_date as episode_release_date,
  pe.episode_number,
  (ci.scheduled_at < pe.release_date) as scheduled_before_release
FROM content_items ci
JOIN podcast_episodes pe ON ci.podcast_episode_id = pe.id
WHERE ci.deleted_at IS NULL
  AND ci.podcast_episode_id IS NOT NULL;

-- Grant access to views
GRANT SELECT ON content_items_enriched TO authenticated;
GRANT SELECT ON queue_items_with_content TO authenticated;
GRANT SELECT ON content_calendar TO authenticated;
GRANT SELECT ON content_with_podcast_context TO authenticated;

COMMENT ON VIEW content_items_enriched IS
'Content items with joined owner and episode data. Use this to avoid N+1 queries.';

COMMENT ON VIEW queue_items_with_content IS
'Queue items with full content details. Use this instead of manual joins.';

COMMENT ON VIEW content_calendar IS
'All scheduled content across all accounts. Useful for calendar displays.';
```

---

## How to Apply These Migrations

### Using Supabase CLI:

```bash
# Connect to your project
supabase link --project-ref your-project-ref

# Create migration files (copy content from above)
supabase migration new add_company_slugs
supabase migration new add_foreign_keys
# ... etc

# Apply migrations
supabase db push

# Or apply to remote:
supabase db push --db-url postgresql://...
```

### Migration Order:
1. ✅ Slugs (001) - Enables slug-based lookups
2. ✅ Foreign Keys (002) - Enforces referential integrity
3. ✅ Unique Constraints (003) - Prevents duplicates
4. ✅ Soft Delete Views (004) - Standardizes delete pattern
5. ✅ Indexes (005) - Improves query performance
6. ✅ Separate Templates (006) - Cleans up data model
7. ✅ Status Audit (007) - Adds change tracking
8. ✅ Init Settings (008) - Populates default settings
9. ✅ Content Metadata (009) - Adds missing fields
10. ✅ Helpful Views (010) - Simplifies queries

### Rollback Plan:
Each migration is reversible. To rollback:

```sql
-- Rollback 010 (views)
DROP VIEW IF EXISTS content_items_enriched CASCADE;
DROP VIEW IF EXISTS queue_items_with_content CASCADE;
DROP VIEW IF EXISTS content_calendar CASCADE;
DROP VIEW IF EXISTS content_with_podcast_context CASCADE;

-- Rollback 009 (metadata)
ALTER TABLE content_items DROP COLUMN IF EXISTS podcast_episode_id;
DROP TRIGGER IF EXISTS sync_queue_metadata_trigger ON queue_items;
DROP FUNCTION IF EXISTS sync_queue_item_metadata();

-- ... (continue in reverse order)
```

### Testing After Migration:

```sql
-- Verify slugs work
SELECT * FROM get_company_by_slug('sourceco');
SELECT * FROM get_company_by_slug('captarget');

-- Verify foreign keys exist
SELECT constraint_name, table_name, constraint_type
FROM information_schema.table_constraints
WHERE table_schema = 'public' 
  AND constraint_type = 'FOREIGN KEY';

-- Verify indexes exist
SELECT indexname, tablename 
FROM pg_indexes 
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- Verify settings populated
SELECT company_id, tom_target_posts_per_day 
FROM ai_posting_settings;

-- Test views
SELECT COUNT(*) FROM content_items_enriched;
SELECT COUNT(*) FROM queue_items_with_content;
SELECT COUNT(*) FROM content_calendar;
```
