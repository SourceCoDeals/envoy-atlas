# Lovable Prompt: Marketing Content Engine Platform Refactor

## 🎯 OBJECTIVE

Fix critical architectural issues in the Marketing Content Engine, focusing on:
1. **AI Scheduler** - Currently schedules all posts on the same day (should distribute across week)
2. **Data Integrity** - Missing foreign keys, unique constraints, proper indexes
3. **Workspace Architecture** - Replace hardcoded UUIDs with slug-based system
4. **Code Duplication** - Create shared package for constants, types, and utilities
5. **React Query Issues** - Fix race conditions, stale data, and duplicate rendering

## 📋 CONTEXT

I have completed a comprehensive audit of the platform and identified critical issues. All documentation is attached:

- `platform-comprehensive-audit.md` - Full platform analysis
- `marketing-engine-audit.md` - AI scheduler deep dive
- `multi-company-architecture-analysis.md` - Workspace strategy
- `phase1-migrations.md` - 10 database migrations with SQL
- `shared-package.md` - Shared constants/types package structure
- `react-query-fixes.md` - React Query cache management fixes
- `schedule-calculator.md` - Centralized scheduling logic class
- `implementation-guide.md` - Complete 4-week implementation plan

**Current Major Bug:** The AI scheduler puts all 5 posts on the same day instead of distributing across the week. This happens because:
- Each queue is processed independently with the same `start_date`
- Code only checks daily max per queue (2 posts), not weekly limits
- CEO (2) + SourceCo (2) + Captarget (1) = 5 total posts fit in one day's limits
- The distribution functions exist but aren't being called in the main flow

## 🏗️ IMPLEMENTATION PLAN

Please implement these fixes in the following order. Each phase builds on the previous one.

---

## PHASE 1: DATABASE MIGRATIONS (Priority: CRITICAL)

### Goal
Add foreign keys, unique constraints, indexes, and company slugs to prevent data corruption and enable slug-based lookups.

### Files to Read First
- `phase1-migrations.md` - Contains all 10 migrations with complete SQL

### Tasks

#### 1.1 Add Company Slugs
**File:** Create `supabase/migrations/20260121_001_add_company_slugs.sql`

**Content:** Copy from `phase1-migrations.md` → Migration 001

**Key Changes:**
- Add `slug` column to `companies` table
- Add `timezone` and `settings` columns
- Populate slugs for existing companies (sourceco, captarget)
- Add unique constraint and index on slug
- Create `get_company_by_slug()` function

**Acceptance Criteria:**
- [ ] Can query `SELECT * FROM get_company_by_slug('sourceco')`
- [ ] Can query `SELECT * FROM get_company_by_slug('captarget')`
- [ ] Both return correct company data
- [ ] `slug` column has unique constraint

#### 1.2 Add Foreign Key Constraints
**File:** Create `supabase/migrations/20260121_002_add_foreign_keys.sql`

**Content:** Copy from `phase1-migrations.md` → Migration 002

**Key Relationships:**
- `content_items.source_content_id` → `content_packs.id`
- `content_items.company_id` → `companies.id`
- `content_items.owner_id` → `profiles.id`
- `content_packs.source_content_id` → `podcast_episodes.id`
- `queue_items.content_item_id` → `content_items.id`
- `queue_items.queue_id` → `publishing_queues.id`
- All other relationships in migration 002

**Acceptance Criteria:**
- [ ] All foreign keys exist (verify with `information_schema.table_constraints`)
- [ ] Cannot insert orphaned records (test by trying to insert invalid FK)
- [ ] Cascade deletes work as expected

#### 1.3 Add Unique Constraints
**File:** Create `supabase/migrations/20260121_003_add_unique_constraints.sql`

**Content:** Copy from `phase1-migrations.md` → Migration 003

**Key Constraints:**
- `UNIQUE (content_item_id, queue_id)` on `queue_items` - Prevent duplicate queue entries
- `UNIQUE (source_content_id, pack_type)` on `content_packs` - Prevent duplicate packs
- `UNIQUE (company_id, target_account, scheduled_at)` partial index on `content_items` - Prevent double-booking slots

**Acceptance Criteria:**
- [ ] Cannot add same content to queue twice (should throw constraint error)
- [ ] Cannot schedule two posts at same time on same account (should throw constraint error)

#### 1.4 Additional Migrations
**Files:** Create migrations 004-010

Copy from `phase1-migrations.md`:
- 004: Soft delete views
- 005: Performance indexes
- 006: Separate templates table (IMPORTANT - fixes content_items dual purpose)
- 007: Status audit trail
- 008: Initialize AI settings (IMPORTANT - populates empty settings table)
- 009: Content metadata
- 010: Helpful views

**Acceptance Criteria:**
- [ ] All 10 migrations applied successfully
- [ ] `ai_posting_settings` table has default rows for all companies
- [ ] `content_templates` table exists and templates migrated
- [ ] All indexes exist
- [ ] All views created and queryable

### How to Apply
```bash
# In Supabase dashboard or CLI
# Apply migrations in order 001 → 010
```

**Testing:**
After migrations, run verification queries from `phase1-migrations.md` bottom section.

---

## PHASE 2: WORKSPACE ARCHITECTURE (Priority: HIGH)

### Goal
Replace hardcoded company UUIDs with slug-based system, create universal workspace context.

### Files to Read First
- `multi-company-architecture-analysis.md` - Strategy and reasoning
- `implementation-guide.md` → Phase 2 - Implementation details

### Tasks

#### 2.1 Create Workspace Context
**File:** `src/contexts/WorkspaceContext.tsx`

**Create new file with:**
```typescript
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

interface Company {
  id: string;
  name: string;
  slug: string;
  timezone: string;
  settings: Record<string, any>;
  created_at: string;
}

interface WorkspaceContextValue {
  workspace: Company | null;
  workspaceSlug: string;
  setWorkspaceSlug: (slug: string) => void;
  isLoading: boolean;
}

const WorkspaceContext = createContext<WorkspaceContextValue | undefined>(undefined);

export function WorkspaceProvider({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [workspaceSlug, setWorkspaceSlugState] = useState<string>('sourceco');

  // Auto-detect workspace from URL path /workspace/:slug
  useEffect(() => {
    const match = location.pathname.match(/\/workspace\/([^\/]+)/);
    if (match) {
      setWorkspaceSlugState(match[1]);
    }
  }, [location.pathname]);

  // Fetch workspace data by slug
  const { data: workspace, isLoading } = useQuery({
    queryKey: ['workspace', workspaceSlug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('slug', workspaceSlug)
        .single();

      if (error) throw error;
      return data as Company;
    },
    enabled: !!workspaceSlug,
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  // Switch workspace helper
  const setWorkspaceSlug = (slug: string) => {
    setWorkspaceSlugState(slug);
    navigate(`/workspace/${slug}/dashboard`);
  };

  return (
    <WorkspaceContext.Provider
      value={{
        workspace: workspace || null,
        workspaceSlug,
        setWorkspaceSlug,
        isLoading,
      }}
    >
      {children}
    </WorkspaceContext.Provider>
  );
}

export function useWorkspace() {
  const context = useContext(WorkspaceContext);
  if (!context) {
    throw new Error('useWorkspace must be used within WorkspaceProvider');
  }
  return context;
}
```

**Acceptance Criteria:**
- [ ] Context provides workspace data
- [ ] Auto-detects workspace from URL
- [ ] `useWorkspace()` hook works in any component

#### 2.2 Update App Routes
**File:** `src/App.tsx`

**Wrap app in WorkspaceProvider:**
```typescript
import { WorkspaceProvider } from '@/contexts/WorkspaceContext';

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WorkspaceProvider>
        <Routes>
          {/* Workspace routes - all pages under /workspace/:slug */}
          <Route path="/workspace/:workspaceSlug" element={<WorkspaceLayout />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="pipeline" element={<Pipeline />} />
            <Route path="calendar" element={<Calendar />} />
            <Route path="queues" element={<Queues />} />
            <Route path="assets" element={<Assets />} />
            <Route path="audiences" element={<Audiences />} />
            <Route path="settings/*" element={<Settings />} />
          </Route>

          {/* Non-workspace routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/settings/profile" element={<Profile />} />
          
          {/* Redirect root to default workspace */}
          <Route 
            path="/" 
            element={<Navigate to="/workspace/sourceco/dashboard" replace />} 
          />
        </Routes>
      </WorkspaceProvider>
    </QueryClientProvider>
  );
}
```

**Acceptance Criteria:**
- [ ] All routes under `/workspace/:slug`
- [ ] Root redirects to `/workspace/sourceco/dashboard`
- [ ] URL shows current workspace

#### 2.3 Add Workspace Indicator to Header
**File:** `src/components/Header.tsx` (or wherever your header is)

**Add workspace indicator and switcher:**
```typescript
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Building2 } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export function Header() {
  const { workspace, workspaceSlug, setWorkspaceSlug } = useWorkspace();

  return (
    <header className="border-b bg-white">
      <div className="flex items-center justify-between px-6 py-3">
        <div className="flex items-center gap-4">
          {/* Logo */}
          <div className="text-xl font-bold">Marketing Engine</div>
          
          {/* Workspace Badge */}
          <div className="flex items-center gap-2 px-3 py-1 bg-blue-50 rounded-md">
            <Building2 className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">
              {workspace?.name || workspaceSlug}
            </span>
          </div>
          
          {/* Workspace Switcher */}
          <Select value={workspaceSlug} onValueChange={setWorkspaceSlug}>
            <SelectTrigger className="w-[140px] h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sourceco">SourceCo</SelectItem>
              <SelectItem value="captarget">Captarget</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {/* Rest of header (user menu, etc.) */}
      </div>
    </header>
  );
}
```

**Acceptance Criteria:**
- [ ] Workspace name visible in header
- [ ] Can switch workspaces via dropdown
- [ ] URL and data update when switching

#### 2.4 Remove Hardcoded Company IDs
**Search and replace across entire codebase:**

**Find:**
```typescript
// Any hardcoded UUIDs like:
"38cfc492-f2dc-4c39-9b99-2310d24309e1"
"9d6c0ee1-4c3d-477d-8070-1a9d822cb19a"

// Or constants like:
const SOURCECO_ID = "38cfc492-...";
const CAPTARGET_ID = "9d6c0ee1-...";
```

**Replace with:**
```typescript
// Use workspace from context:
const { workspace } = useWorkspace();
const companyId = workspace.id;

// Or use slug for comparisons:
if (workspace.slug === 'sourceco') {
  // SourceCo-specific logic
}
```

**Files likely to have hardcoded IDs:**
- Any hooks in `src/hooks/`
- Components that fetch data
- Edge function calls
- Test files

**Acceptance Criteria:**
- [ ] No hardcoded UUIDs in codebase (search confirms)
- [ ] All queries use `workspace.id` or fetch by slug
- [ ] Tests don't rely on specific UUIDs

---

## PHASE 3: SHARED CONSTANTS PACKAGE (Priority: HIGH)

### Goal
Create a shared package for constants, types, and utilities to eliminate duplication and ensure consistency.

### Files to Read First
- `shared-package.md` - Complete package structure and code

### Tasks

#### 3.1 Create Package Structure
**Create directory:**
```bash
mkdir -p packages/shared/src/{constants,types,utils,services}
```

**Files to create:**
- `packages/shared/package.json`
- `packages/shared/tsconfig.json`
- `packages/shared/src/index.ts`
- `packages/shared/src/constants/ai-posting.ts`
- `packages/shared/src/constants/scheduling.ts`
- `packages/shared/src/constants/content.ts`
- `packages/shared/src/types/database.ts`
- `packages/shared/src/types/scheduling.ts`
- `packages/shared/src/utils/datetime.ts`
- `packages/shared/src/services/ScheduleCalculator.ts`

**Copy all file contents from `shared-package.md`**

**Key Constants to Define:**
```typescript
// AI_POSTING_DEFAULTS - Single source of truth
export const AI_POSTING_DEFAULTS = {
  tom_target_posts_per_day: 2,
  allow_second_post_tom: true,
  min_hours_between_tom_posts: 6,
  sourceco_posts_per_week_min: 3,
  sourceco_posts_per_week_max: 5,
  captarget_posts_per_week_min: 3,
  captarget_posts_per_week_max: 5,
  min_hours_between_any_posts: 4,
  carousel_after_carousel_hours: 24,
  video_after_video_hours: 24,
  poll_cooldown_hours: 72,
  cross_account_same_idea_hours: 36,
  weekend_posting_allowed: false,
  preferred_times: ['09:00', '14:00'],
  default_timezone: 'America/Chicago',
} as const;
```

#### 3.2 Setup Monorepo
**Root `package.json`:**
```json
{
  "name": "marketing-content-engine",
  "private": true,
  "workspaces": [
    "packages/*"
  ],
  "scripts": {
    "build:shared": "cd packages/shared && npm run build"
  }
}
```

**Install dependencies:**
```bash
cd packages/shared
npm install zod
npm install -D typescript vitest
npm run build
```

#### 3.3 Link to Apps
**In edge functions and frontend, add:**
```json
{
  "dependencies": {
    "@marketing-engine/shared": "workspace:*"
  }
}
```

**Run:**
```bash
npm install
```

#### 3.4 Replace Hardcoded Constants
**Find and replace across codebase:**

**BEFORE:**
```typescript
// In edge function:
const DEFAULT_TIMEZONE = 'America/New_York'; // ❌ Inconsistent

// In frontend:
const defaultSettings = {
  tom_target_posts_per_day: 2,
  // ... duplicated
};

// In migrations:
DEFAULT 'America/Chicago' // ❌ Different from code!
```

**AFTER:**
```typescript
import { AI_POSTING_DEFAULTS } from '@marketing-engine/shared';

const settings = dbSettings || AI_POSTING_DEFAULTS;
const timezone = settings.default_timezone; // Always 'America/Chicago'
```

**Files to update:**
- `supabase/functions/ai-schedule-assistant/index.ts`
- `src/hooks/useAIPostingSettings.tsx`
- `src/pages/AIPostingSettings.tsx`
- Any other files with hardcoded defaults

**Acceptance Criteria:**
- [ ] Shared package builds successfully
- [ ] Can import from `@marketing-engine/shared` in frontend
- [ ] Can import from `@marketing-engine/shared` in edge functions
- [ ] No duplicate constants in codebase
- [ ] All defaults come from shared package

---

## PHASE 4: REACT QUERY FIXES (Priority: HIGH)

### Goal
Fix race conditions, stale data, and duplicate rendering by properly configuring React Query and using workspace-aware query keys.

### Files to Read First
- `react-query-fixes.md` - Complete fixes with examples

### Tasks

#### 4.1 Update Global Query Client Config
**File:** `src/lib/queryClient.ts`

**Replace with:**
```typescript
import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 0,              // Data is stale immediately after fetch
      gcTime: 1000 * 60 * 5,     // Keep in cache for 5 minutes
      refetchOnMount: true,       // Always refetch when component mounts
      refetchOnWindowFocus: false, // Don't refetch on tab switch
      retry: 1,                   // Retry failed queries once
      throwOnError: false,        // Don't throw errors by default
    },
    mutations: {
      retry: 0,                   // Don't retry mutations
      throwOnError: false,
    },
  },
});
```

**Acceptance Criteria:**
- [ ] Query client uses new configuration
- [ ] No more stale data issues

#### 4.2 Create useWorkspaceQuery Hook
**File:** `src/hooks/useWorkspaceQuery.tsx`

**Copy complete implementation from `react-query-fixes.md` → Fix 2**

**Key feature:**
- Automatically includes `workspace.id` in query key
- Auto-filters by `company_id`
- Returns strongly typed data

**Usage:**
```typescript
const { data: contentItems } = useWorkspaceQuery<ContentItem>('content_items', {
  filter: { status: 'in_review' }
});
// Automatically filtered by current workspace!
```

**Acceptance Criteria:**
- [ ] Hook works in any component
- [ ] Always filters by workspace
- [ ] Query key includes workspace ID

#### 4.3 Update useContentItems Hook
**File:** `src/hooks/useContentItems.tsx`

**Key changes:**
1. Include `workspace.id` in query key
2. Add deduplication in `select`
3. Configure proper cache settings
4. Add helper methods for invalidation

**Copy implementation from `react-query-fixes.md` → Fix 1**

**Acceptance Criteria:**
- [ ] Query key includes workspace ID: `['content-items', workspace?.id]`
- [ ] No duplicate items in UI
- [ ] Switching workspaces shows correct data

#### 4.4 Fix useQueueChat Hook
**File:** `src/hooks/useQueueChat.tsx`

**CRITICAL FIX for conversation history bug:**

**Current problem:**
```typescript
// User sends "schedule posts" → cache invalidates
// AI responds with preview → cache invalidates
// User sends "confirm" → reads stale cache (no preview!)
```

**Solution:**
```typescript
const sendMessage = useMutation({
  mutationFn: async (message: string) => {
    // 1. Save user message
    await saveUserMessage(message);
    
    // 2. Wait for cache to update
    await queryClient.invalidateQueries(['queue-chat-messages', workspace.id]);
    await queryClient.refetchQueries(['queue-chat-messages', workspace.id]);
    
    // 3. NOW read fresh conversation history
    const freshMessages = queryClient.getQueryData(['queue-chat-messages', workspace.id]);
    
    // 4. Send to AI with complete history
    const response = await callAI(message, freshMessages);
    
    // 5. Save AI response
    await saveAIMessage(response);
    
    // 6. Final refetch
    await queryClient.refetchQueries(['queue-chat-messages', workspace.id]);
  }
});
```

**Copy complete implementation from `react-query-fixes.md` → Fix 3**

**Acceptance Criteria:**
- [ ] User sends message → saved → cache updates
- [ ] AI responds → saved → cache updates
- [ ] User sends "confirm" → AI has full history including preview
- [ ] No race conditions

#### 4.5 Update All Content Mutations
**File:** `src/hooks/useContentMutations.tsx`

**Add proper mutation patterns:**
- `onSuccess` for invalidation
- `onSettled` for guaranteed refetch
- Proper optimistic updates with rollback (optional)

**Copy implementation from `react-query-fixes.md` → Fix 4**

**Acceptance Criteria:**
- [ ] Create/update/delete operations work
- [ ] UI updates immediately
- [ ] No duplicate items after mutations

#### 4.6 Update All Queries to Include Workspace ID
**Search for all `useQuery` calls:**
```bash
grep -r "useQuery(" src/
```

**Update each to include `workspace.id` in key:**

**BEFORE:**
```typescript
useQuery({
  queryKey: ['content-items'], // ❌ No workspace ID
  // ...
});
```

**AFTER:**
```typescript
const { workspace } = useWorkspace();

useQuery({
  queryKey: ['content-items', workspace?.id], // ✅ Includes workspace
  // ...
  enabled: !!workspace?.id,
});
```

**Acceptance Criteria:**
- [ ] All queries include workspace ID in key
- [ ] No cache pollution across workspaces
- [ ] Switching workspaces shows correct data immediately

---

## PHASE 5: SCHEDULE CALCULATOR (Priority: CRITICAL)

### Goal
Create centralized ScheduleCalculator class that both frontend and backend use for all scheduling calculations.

### Files to Read First
- `schedule-calculator.md` - Complete class implementation
- `implementation-guide.md` → Phase 5

### Tasks

#### 5.1 Create ScheduleCalculator Class
**File:** `packages/shared/src/services/ScheduleCalculator.ts`

**Copy complete implementation from `schedule-calculator.md`**

**Key methods:**
- `getWeeklyLimit(account)` - Min/max posts per week
- `getDailyLimit(account, date)` - Max posts per day
- `calculateWeeklyCapacity(account, weekBounds, existing)` - Remaining slots
- `getOptimalSlots(date, account)` - Find best time slots
- `findBestSlot(date, account, contentType, existing)` - Single best slot
- `validateContentTypeSpacing()` - Check carousel→carousel spacing
- `validateSourceContentSpacing()` - Check same-source spacing
- `validateCrossAccountSpacing()` - Check cross-account spacing

**Export from shared package:**
```typescript
// packages/shared/src/index.ts
export { ScheduleCalculator, defaultScheduleCalculator } from './services/ScheduleCalculator';
```

**Acceptance Criteria:**
- [ ] Class compiles without errors
- [ ] Can instantiate: `new ScheduleCalculator(settings)`
- [ ] All methods return expected types

#### 5.2 Add Tests for ScheduleCalculator
**File:** `packages/shared/src/services/ScheduleCalculator.test.ts`

**Copy test examples from `schedule-calculator.md`**

**Key tests:**
- Weekly limit calculations
- Daily limit calculations
- Time slot tier scoring
- Content spacing validation
- Cross-account spacing

**Run:**
```bash
cd packages/shared
npm test
```

**Acceptance Criteria:**
- [ ] All tests pass
- [ ] Calculator behaves as expected

---

## PHASE 6: FIX AI SCHEDULER (Priority: CRITICAL)

### Goal
Fix the AI scheduler to actually distribute posts across the week instead of putting everything on the same day.

### Files to Read First
- `marketing-engine-audit.md` - Root cause analysis
- `implementation-guide.md` → Phase 6 - Integration steps

### Context
**The Current Bug:**
The AI scheduler schedules all 5 posts on the same day because:
1. AI calls `schedule_posts` with same `start_date` for all queues
2. Code processes each queue independently
3. Only checks daily max per queue (CEO: 2, SourceCo: 2, Captarget: 1)
4. All 5 posts fit within daily limits → all scheduled on same day
5. The distribution functions exist but aren't called properly

**The Fix:**
1. Load full month context BEFORE scheduling
2. Actually call `distributeAcrossWeeks()` function
3. Use ScheduleCalculator for all calculations
4. Enforce weekly limits in code, not just AI prompt

### Tasks

#### 6.1 Add Logging (Temporary Diagnostic)
**File:** `supabase/functions/ai-schedule-assistant/index.ts`

**Add logging at key points:**
```typescript
// At start of schedule_posts action
console.log('🔵 SCHEDULE_POSTS called:', {
  queue_name,
  start_date,
  items_to_schedule,
  timestamp: new Date().toISOString()
});

// Before scheduling loop
console.log('🟡 About to schedule:', {
  queueName: queue.name,
  itemCount: queueItems.length,
  existingScheduledThisWeek: scheduledThisWeek.length
});

// After each item scheduled
console.log('🟢 Scheduled item:', {
  title: item.title,
  scheduled_at: scheduledAt,
  target_account: queue.target_account
});

// After all scheduling
console.log('🔵 SCHEDULE_POSTS complete:', {
  totalScheduled: scheduledItems.length,
  warnings: warnings.length
});
```

**Deploy and test:**
```bash
supabase functions deploy ai-schedule-assistant
```

**Check logs to confirm the bug:**
```bash
supabase functions logs ai-schedule-assistant
```

**Expected findings:**
- All items have same `scheduled_at` date
- `distributeAcrossWeeks` is NOT being called
- `loadScheduleContext` is NOT being called

#### 6.2 Create Context Loader
**File:** `supabase/functions/ai-schedule-assistant/lib/context-loader.ts`

**Copy implementation from `implementation-guide.md` → Phase 6.3**

**Key function:**
```typescript
export async function loadScheduleContext(
  companyId: string,
  targetMonth: Date,
  supabase: any
): Promise<ScheduleContext> {
  // 1. Query all scheduled items for month
  // 2. Build weekly totals by account
  // 3. Build daily totals by account
  // 4. Return context with helper methods
}
```

**Acceptance Criteria:**
- [ ] Function loads all scheduled items for month
- [ ] Builds weekly and daily totals
- [ ] Returns context with helper methods

#### 6.3 Update Distributor to Use ScheduleCalculator
**File:** `supabase/functions/ai-schedule-assistant/lib/distributor.ts`

**Copy implementation from `implementation-guide.md` → Phase 6.4**

**Key changes:**
1. Accept `ScheduleCalculator` as parameter
2. Use `calculator.getWeeklyLimit()` instead of hardcoded values
3. Use `calculator.calculateWeeklyCapacity()` for capacity checks
4. Use `calculator.findBestSlot()` for time slot selection
5. Use `calculator.validateContentTypeSpacing()` for spacing validation
6. Implement round-robin distribution across days

**Acceptance Criteria:**
- [ ] Function uses ScheduleCalculator for all calculations
- [ ] Distributes items across multiple days (not all on one day)
- [ ] Respects weekly limits
- [ ] Returns warnings for blocked items

#### 6.4 Refactor Main Scheduling Flow
**File:** `supabase/functions/ai-schedule-assistant/index.ts`

**In the `schedule_posts` action handler, replace current logic with:**

```typescript
import { ScheduleCalculator, AI_POSTING_DEFAULTS } from '@marketing-engine/shared';
import { loadScheduleContext } from './lib/context-loader.ts';
import { distributeAcrossWeeks } from './lib/distributor.ts';

async function handleSchedulePosts(action: ScheduleAction) {
  const { queue_name, start_date, items_to_schedule } = action.parameters;
  
  console.log('🔵 Starting schedule_posts with context loading');
  
  // 1. Get settings and initialize calculator
  const { data: dbSettings } = await supabase
    .from('ai_posting_settings')
    .select('*')
    .eq('company_id', companyId)
    .single();
  
  const settings = dbSettings || AI_POSTING_DEFAULTS;
  const calculator = new ScheduleCalculator(settings);
  
  console.log('✅ Calculator initialized with settings');
  
  // 2. Load full month context (THIS WAS MISSING!)
  const targetMonth = new Date(start_date);
  const context = await loadScheduleContext(
    companyId,
    targetMonth,
    supabase
  );
  
  console.log('✅ Context loaded:', {
    scheduledItemsCount: context.scheduledItems.length,
    weeklyTotals: context.weeklyTotals,
    dailyTotals: context.dailyTotals
  });
  
  // 3. Get queue and items
  const { data: queue } = await supabase
    .from('publishing_queues')
    .select('*')
    .eq('name', queue_name)
    .eq('company_id', companyId)
    .single();
  
  const { data: queueItems } = await supabase
    .from('queue_items')
    .select(`
      *,
      content_item:content_items(*)
    `)
    .eq('queue_id', queue.id)
    .is('scheduled_at', null)
    .order('created_at', { ascending: true });
  
  const itemsToProcess = items_to_schedule === -1 
    ? queueItems 
    : queueItems.slice(0, items_to_schedule);
  
  console.log('✅ Queue loaded:', {
    queueName: queue.name,
    itemCount: itemsToProcess.length
  });
  
  // 4. Use distribution function (THIS WAS NOT BEING CALLED!)
  const distribution = await distributeAcrossWeeks(
    itemsToProcess,
    queue,
    new Date(start_date),
    context,
    settings,
    calculator
  );
  
  console.log('✅ Distribution complete:', {
    scheduled: distribution.scheduledItems.length,
    blocked: distribution.blocked.length,
    warnings: distribution.warnings.length
  });
  
  // 5. Actually schedule the distributed items
  const scheduled = [];
  for (const item of distribution.scheduledItems) {
    const { data: scheduledItem, error } = await supabase
      .from('content_items')
      .update({
        scheduled_at: item.scheduledAt.toISOString(),
        target_account: queue.target_account,
        status: 'scheduled'
      })
      .eq('id', item.content_item_id)
      .select()
      .single();
    
    if (error) {
      console.error('❌ Failed to schedule item:', error);
      continue;
    }
    
    // Delete from queue
    await supabase
      .from('queue_items')
      .delete()
      .eq('content_item_id', item.content_item_id);
    
    scheduled.push(scheduledItem);
    
    console.log('✅ Scheduled:', {
      title: scheduledItem.title,
      scheduled_at: scheduledItem.scheduled_at,
      tier: item.slotTier
    });
  }
  
  return {
    scheduled,
    warnings: distribution.warnings,
    blocked: distribution.blocked.map(b => ({
      title: b.item.title,
      reason: b.reason
    }))
  };
}
```

**Critical changes:**
1. ✅ Load schedule context FIRST
2. ✅ Initialize ScheduleCalculator with settings
3. ✅ Call distributeAcrossWeeks (was missing!)
4. ✅ Use distributed schedule (not sequential)
5. ✅ Log everything for debugging

**Acceptance Criteria:**
- [ ] Context is loaded before scheduling
- [ ] Distributor is called
- [ ] Items are distributed across multiple days
- [ ] Weekly limits are enforced
- [ ] Logs show proper distribution

#### 6.5 Update System Prompt
**File:** `supabase/functions/ai-schedule-assistant/index.ts`

**Update the system prompt to emphasize:**
```typescript
const systemPrompt = `
You are an AI scheduling assistant for social media content.

CRITICAL: Weekly limits are ENFORCED BY CODE, not just guidance:
- CEO (Tom): No strict weekly max, but ${settings.tom_target_posts_per_day} per day
- SourceCo: ${settings.sourceco_posts_per_week_min}-${settings.sourceco_posts_per_week_max} posts per week (HARD LIMIT)
- Captarget: ${settings.captarget_posts_per_week_min}-${settings.captarget_posts_per_week_max} posts per week (HARD LIMIT)

When you call schedule_posts, the code will:
1. Load existing schedule for the month
2. Calculate remaining weekly capacity
3. Distribute posts across multiple days using round-robin
4. Enforce all spacing rules (content type, cross-account, podcast release dates)
5. Return warnings if weekly limits are exceeded

Your role is to:
- Interpret user intent ("schedule over the next week", "schedule these 5 items", etc.)
- Call schedule_posts with appropriate parameters
- Explain the results to the user
- Handle confirmation flows

DO NOT worry about manual distribution - the code handles that automatically.
`;
```

**Acceptance Criteria:**
- [ ] Prompt reflects that code enforces limits
- [ ] AI understands its role is intent interpretation, not manual scheduling

#### 6.6 Test the Fix
**Test Scenario 1: Basic Distribution**
```
User: "Schedule these 5 posts over the next week"
Expected: Items spread Mon-Fri, not all on Monday
```

**Test Scenario 2: Weekly Limits**
```
User: "Schedule all 8 SourceCo items"
Expected: 5 scheduled this week, 3 next week with warning
```

**Test Scenario 3: Multiple Queues**
```
User: "Schedule everything in all queues"
Expected: CEO, SourceCo, Captarget posts distributed across days
```

**Check logs:**
```bash
supabase functions logs ai-schedule-assistant --follow
```

**Verify in database:**
```sql
SELECT 
  title,
  scheduled_at,
  target_account,
  DATE(scheduled_at) as schedule_date
FROM content_items
WHERE status = 'scheduled'
  AND scheduled_at >= NOW()
ORDER BY scheduled_at;
```

**Acceptance Criteria:**
- [ ] Posts spread across multiple days (not all on same day)
- [ ] Weekly limits enforced (warnings for overflow)
- [ ] Logs show context loading and distribution
- [ ] Tier 1 slots used preferentially

---

## PHASE 7: TESTING & VALIDATION

### Goal
Ensure all fixes work together and no regressions.

### Tasks

#### 7.1 Test Workspace Switching
**Steps:**
1. Navigate to `/workspace/sourceco/dashboard`
2. Verify SourceCo content appears
3. Switch to Captarget via dropdown
4. Verify URL changes to `/workspace/captarget/dashboard`
5. Verify Captarget content appears
6. Verify no SourceCo content visible

**Acceptance Criteria:**
- [ ] Workspace switching works smoothly
- [ ] Content filters correctly
- [ ] No data leakage across workspaces

#### 7.2 Test Queue Chat Conversation History
**Steps:**
1. Open Queue Chat
2. Send: "Schedule these posts over the next week"
3. AI responds with simulation preview
4. Immediately send: "confirm"
5. Check logs to verify AI received full history

**Acceptance Criteria:**
- [ ] AI receives complete conversation history
- [ ] "confirm" works without re-explaining
- [ ] No race conditions

#### 7.3 Test AI Scheduler Distribution
**Steps:**
1. Add 5 items to queue (mix of CEO, SourceCo, Captarget)
2. Send: "Schedule all items over the next week"
3. Check scheduled_at dates in database
4. Verify posts are on different days

**Acceptance Criteria:**
- [ ] Posts distributed across multiple days
- [ ] No more than daily limit per account per day
- [ ] Weekly limits respected

#### 7.4 Test Content Spacing
**Steps:**
1. Schedule a carousel on Monday 9 AM
2. Try to schedule another carousel on Monday 11 AM
3. Verify warning about 24-hour gap
4. Verify second carousel moved to Tuesday 9 AM

**Acceptance Criteria:**
- [ ] Content type spacing enforced
- [ ] Warnings displayed
- [ ] Adjusted times correct

#### 7.5 Test Database Constraints
**Steps:**
1. Try to add same content to queue twice
2. Verify unique constraint error
3. Try to schedule two posts at same time on same account
4. Verify unique constraint error

**Acceptance Criteria:**
- [ ] Cannot create duplicates
- [ ] Constraints working as expected

---

## ACCEPTANCE CRITERIA FOR COMPLETE REFACTOR

### Database
- [ ] All 10 migrations applied successfully
- [ ] Foreign keys exist and enforced
- [ ] Unique constraints prevent duplicates
- [ ] Indexes improve query performance
- [ ] AI posting settings populated for all companies

### Workspace Architecture
- [ ] Company slugs work (sourceco, captarget)
- [ ] No hardcoded UUIDs in codebase
- [ ] WorkspaceProvider wraps entire app
- [ ] All routes under `/workspace/:slug`
- [ ] Workspace indicator visible in header
- [ ] Switching workspaces works smoothly

### Shared Package
- [ ] Package builds successfully
- [ ] Can import from `@marketing-engine/shared` in frontend
- [ ] Can import from `@marketing-engine/shared` in edge functions
- [ ] No duplicate constants
- [ ] ScheduleCalculator compiles and tests pass

### React Query
- [ ] All query keys include workspace.id
- [ ] No duplicate items in UI
- [ ] No stale data in cache
- [ ] Conversation history complete
- [ ] Mutations work correctly

### AI Scheduler
- [ ] Posts distribute across multiple days (NOT all on same day)
- [ ] Weekly limits enforced by code
- [ ] Daily limits respected
- [ ] Content spacing rules applied
- [ ] Warnings displayed for blocked items
- [ ] Podcast release dates enforced

### User Experience
- [ ] Workspace switching smooth
- [ ] Calendar shows correct content
- [ ] Pipeline shows correct content
- [ ] Queues show correct content
- [ ] No "which company am I in?" confusion
- [ ] AI scheduler provides clear feedback

---

## 🚨 CRITICAL NOTES FOR LOVABLE

### Order Matters
Please implement phases in order:
1. Database first (provides foundation)
2. Workspace architecture (enables proper filtering)
3. Shared package (provides tools)
4. React Query (fixes UI issues)
5. AI scheduler (uses all the above)

### Testing Between Phases
After each phase, test before moving to next:
- Run the application
- Check for errors
- Verify phase-specific acceptance criteria

### When You Get Stuck
If something isn't clear:
1. Re-read the relevant documentation file
2. Check the examples in implementation-guide.md
3. Look at the acceptance criteria
4. Ask for clarification if needed

### Common Pitfalls to Avoid
1. **Don't skip the context loading** - This is why scheduler is broken
2. **Don't forget workspace.id in query keys** - This causes cache pollution
3. **Don't use hardcoded UUIDs** - Always use slugs or workspace.id
4. **Don't skip migrations** - They must be applied in order
5. **Don't forget to await refetches** - This causes race conditions

### Success Indicators
You'll know it's working when:
- ✅ 5 posts spread across Mon-Fri (not all on Monday)
- ✅ Switching workspaces shows different content
- ✅ No duplicate items anywhere
- ✅ "confirm" in queue chat works immediately
- ✅ Weekly limits enforced with warnings

---

## 📚 REFERENCE DOCUMENTS

All implementation details are in these attached files:
- `platform-comprehensive-audit.md` - Full issue analysis
- `marketing-engine-audit.md` - AI scheduler deep dive
- `multi-company-architecture-analysis.md` - Workspace strategy
- `phase1-migrations.md` - All SQL migrations
- `shared-package.md` - Complete package code
- `react-query-fixes.md` - Cache management fixes
- `schedule-calculator.md` - Calculator class
- `implementation-guide.md` - Complete roadmap

**Please read these files carefully for complete context and code examples.**

---

## 🎯 FINAL CHECKLIST

When complete, verify:
- [ ] Can navigate to `/workspace/sourceco/dashboard`
- [ ] Can navigate to `/workspace/captarget/dashboard`
- [ ] Content filters correctly by workspace
- [ ] Schedule 5 items → distributed across week (NOT same day)
- [ ] Queue chat "confirm" works immediately
- [ ] No duplicate items in Pipeline
- [ ] No hardcoded UUIDs in code
- [ ] All tests pass
- [ ] No TypeScript errors
- [ ] No console errors

**If all checklist items pass, the refactor is complete! 🎉**
