# Platform Refactor - Complete Deliverables
**Date:** January 21, 2026  
**Project:** Marketing Content Engine  
**Scope:** Full platform audit and refactoring plan

---

## 📦 DELIVERED DOCUMENTS

### 1. **multi-company-architecture-analysis.md**
**Question Answered:** Should we simplify SourceCo vs Captarget separation?

**Recommendation:** Keep them separate (they ARE different brands), but fix the implementation with:
- Slugs instead of hardcoded UUIDs
- Universal workspace context
- Hierarchical settings
- Clear workspace indicator in UI

**Key Insight:** The problem isn't the separation—it's that the implementation uses hardcoded UUIDs and inconsistent workspace filtering.

**Effort:** 6-9 days for complete migration  
**Impact:** Clean architecture, easy to add new companies, no more UUID hell

---

### 2. **platform-comprehensive-audit.md**
**Full platform audit covering:**

**Architecture Issues:**
- Content items table doing too much (templates + content)
- Queue items duplicating data from content items
- Podcast data chain too long (3-hop joins)
- No foreign key constraints
- Soft delete inconsistency

**Hardcoded Values:**
- Company IDs hardcoded as UUIDs
- AI defaults in 3 different places
- Magic numbers throughout code
- Timezone defaults inconsistent

**Calculations Done Multiple Ways:**
- Weekly post counts calculated differently in 3 places
- Date/time formatting inconsistent
- No single source of truth

**Data Integrity Issues:**
- Missing foreign keys → orphaned records possible
- No uniqueness constraints → duplicates created
- Soft delete pattern inconsistent

**Frontend Issues:**
- React Query race conditions
- Duplicate items in UI
- Stale data in cache
- Workspace filtering not universal

**Top 10 Critical Findings** with priority levels and fixes

---

### 3. **phase1-migrations.md**
**10 database migrations for data integrity:**

1. **Add Company Slugs** - Enable slug-based lookups
2. **Add Foreign Keys** - Enforce referential integrity
3. **Add Unique Constraints** - Prevent duplicates
4. **Soft Delete Views** - Standardize delete pattern
5. **Add Indexes** - Improve query performance
6. **Separate Templates** - Clean up data model
7. **Status Audit Trail** - Track status changes
8. **Initialize AI Settings** - Populate defaults
9. **Content Metadata** - Add missing fields
10. **Helpful Views** - Simplify queries

**Includes:**
- Complete SQL for all migrations
- Testing queries
- Rollback procedures
- Application order

**Estimated Effort:** 3-4 days  
**Impact:** Prevents data corruption, eliminates orphaned records

---

### 4. **shared-package.md**
**Complete shared package structure:**

**Package:** `@marketing-engine/shared`

**Contents:**
- Constants (AI defaults, scheduling, content types)
- Types (database, scheduling, content)
- Utils (DateTimeUtils class)
- Validators (content, scheduling)

**Benefits:**
- ✅ Single source of truth for defaults
- ✅ Shared types across frontend/backend
- ✅ Reusable validation logic
- ✅ Consistent date handling

**Includes:**
- Full package structure
- All TypeScript files
- Usage examples
- Setup instructions

**Estimated Effort:** 2-3 days  
**Impact:** Eliminates duplicate code, enables type safety

---

### 5. **react-query-fixes.md**
**Fixes for cache management issues:**

**Problems Solved:**
- Race conditions on rapid mutations
- Duplicate items appearing in UI
- Stale conversation history in queue chat
- Cache pollution across workspaces
- Optimistic updates without rollback

**Fixes:**
1. Proper query key structure (include workspace.id)
2. Workspace-aware query hook
3. Sequential operations with awaited refetches
4. Proper mutation patterns with rollback
5. Global query configuration

**Includes:**
- Complete code examples
- Before/after comparisons
- Test scenarios
- Migration steps

**Estimated Effort:** 2-3 days  
**Impact:** Eliminates race conditions, fixes duplicate rendering

---

### 6. **schedule-calculator.md**
**Centralized scheduling logic class:**

**Class:** `ScheduleCalculator`

**Methods:**
- `getWeeklyLimit(account)` - Get min/max posts per week
- `getDailyLimit(account, date)` - Get max posts per day
- `calculateWeeklyCapacity()` - Remaining slots this week
- `getOptimalSlots()` - Find best time slots
- `findBestSlot()` - Find single best slot
- `validateContentTypeSpacing()` - Carousel→carousel spacing
- `validateSourceContentSpacing()` - Same-source spacing
- `validateCrossAccountSpacing()` - Cross-account spacing

**Benefits:**
- ✅ Single source of truth for all calculations
- ✅ Frontend and backend use same logic
- ✅ Easily testable
- ✅ Type-safe
- ✅ Reusable across edge functions, frontend, analytics

**Includes:**
- Complete TypeScript class
- Usage examples for all scenarios
- Test examples

**Estimated Effort:** 1-2 days  
**Impact:** Eliminates calculation inconsistencies

---

### 7. **implementation-guide.md**
**Complete step-by-step implementation plan:**

**Timeline:** 4 weeks
- **Week 1:** Database + Workspace architecture
- **Week 2:** Frontend stability (React Query + Calculator)
- **Week 3:** AI scheduler integration
- **Week 4:** Polish + documentation

**Includes:**
- Detailed daily schedule
- Phase-by-phase implementation
- Test scenarios for each phase
- Deployment checklist
- Rollback procedures
- Success metrics
- Documentation to create

**Key Phases:**
1. Database migrations (A)
2. Workspace architecture (slugs + context)
3. Shared package setup (B)
4. React Query fixes (C)
5. ScheduleCalculator integration (D)
6. AI scheduler refactor
7. Testing
8. Deployment

---

### 8. **marketing-engine-audit.md**
**Deep dive into AI scheduler issues:**

**Focus:** Why scheduling puts everything on the same day

**Root Causes Identified:**
1. AI calls `schedule_posts` with same `start_date` for all queues
2. Code only checks daily max per queue, not weekly limits
3. With 2+2+1=5 posts, all fit in one day's daily limits
4. Weekly limits mentioned in prompt but not enforced by code
5. Distribution functions exist but aren't called properly

**The Bug:**
```typescript
// Current (broken):
for (const action of actions) {
  // Old sequential logic still executing
  // Each queue processed independently
  // Same start_date for all
  // Result: All 5 posts on same day
}

// Should be (fixed):
// 1. Load month context FIRST
// 2. Use distributeAcrossWeeks()
// 3. Enforce weekly limits in code
// 4. Round-robin across days
```

**Includes:**
- Detailed debugging steps
- Logging patches to deploy
- Test scenarios
- Priority fixes

---

## 🎯 QUICK START GUIDE

### If You Want to Fix the AI Scheduler First:
1. Read **marketing-engine-audit.md** for the diagnosis
2. Read **schedule-calculator.md** to understand the fix
3. Read **implementation-guide.md** → Phase 6 for integration steps

### If You Want to Fix Workspace Architecture:
1. Read **multi-company-architecture-analysis.md** for the decision
2. Read **implementation-guide.md** → Phase 2 for implementation
3. Read **phase1-migrations.md** → Migration 001 for database changes

### If You Want to Fix Data Integrity:
1. Read **platform-comprehensive-audit.md** → Data Integrity Issues
2. Read **phase1-migrations.md** for all migrations
3. Apply migrations in order

### If You Want to Fix React Query Issues:
1. Read **platform-comprehensive-audit.md** → Frontend Issues
2. Read **react-query-fixes.md** for complete fixes
3. Read **implementation-guide.md** → Phase 4 for integration

---

## 💰 BIGGEST WINS FOR EFFORT

### High Impact, Low Effort (Do First):
1. **Add company slugs** (1 day) → Eliminates UUID hardcoding
2. **Fix React Query keys** (1 day) → Fixes duplicate items
3. **Add foreign key constraints** (1 day) → Prevents data corruption
4. **Standardize timezone** (2 hours) → Fixes scheduling bugs

### High Impact, Medium Effort (Do Second):
1. **Create shared package** (2-3 days) → Single source of truth
2. **Implement ScheduleCalculator** (1-2 days) → Consistent calculations
3. **Fix workspace context** (2-3 days) → Universal filtering
4. **Add uniqueness constraints** (1 day) → No more duplicates

### High Impact, High Effort (Do Third):
1. **Refactor AI scheduler** (3-5 days) → Actually distributes posts
2. **Separate templates table** (2-3 days) → Cleaner data model
3. **Add comprehensive tests** (1 week) → Prevents regressions

---

## 📊 ESTIMATED TOTAL EFFORT

**Phase 1 (Data Integrity):** 3-4 days  
**Phase 2 (Workspace Architecture):** 2-3 days  
**Phase 3 (Shared Package):** 2-3 days  
**Phase 4 (React Query Fixes):** 2-3 days  
**Phase 5 (Schedule Calculator):** 1-2 days  
**Phase 6 (AI Scheduler Integration):** 3-5 days  
**Phase 7 (Testing):** 2-3 days  
**Phase 8 (Documentation):** 2-3 days  

**Total:** ~20-30 working days (4-6 weeks for one developer)

With parallelization or a team, could be done in 2-3 weeks.

---

## 🎯 RECOMMENDED APPROACH

### Option 1: Emergency Fix (1 week)
**Just fix the AI scheduler:**
1. Add logging to diagnose exact issue
2. Implement ScheduleCalculator
3. Refactor distributor to use calculator
4. Test and deploy

**Gets you:** Working distribution across days  
**Leaves:** Other architectural issues for later

### Option 2: Foundation First (2-3 weeks)
**Fix architecture properly:**
1. Week 1: Database migrations + workspace architecture
2. Week 2: Shared package + React Query fixes
3. Week 3: AI scheduler integration + testing

**Gets you:** Solid foundation + working scheduler  
**Leaves:** Some polish for later

### Option 3: Complete Refactor (4-6 weeks)
**Follow full implementation guide:**
- All phases in order
- Comprehensive testing
- Full documentation
- Production-ready

**Gets you:** Everything fixed properly

---

## 🚨 CRITICAL QUESTIONS TO ANSWER

Before starting implementation:

1. **Timezone:** Stick with Chicago? (matching your location)  
   **Recommendation:** Yes, use `America/Chicago` everywhere

2. **Week Definition:** Use ISO weeks (Mon-Sun)?  
   **Recommendation:** Yes, ISO weeks are standard

3. **Delete Strategy:** Always soft delete with views?  
   **Recommendation:** Yes, soft delete + views for audit trail

4. **Company Architecture:** Keep separate or merge?  
   **Recommendation:** Keep separate, fix implementation with slugs

5. **Settings Precedence:** Company overrides global?  
   **Recommendation:** Yes, hierarchical (global → company → user)

---

## 📞 NEXT STEPS

**Immediate Actions (Today):**
1. Review all documents
2. Decide on approach (Option 1, 2, or 3)
3. Answer the 5 critical questions
4. Prioritize which fixes to start with

**This Week:**
1. Set up shared package structure
2. Apply first 3 database migrations
3. Add workspace context
4. Test in staging

**This Month:**
1. Complete chosen approach
2. Test thoroughly
3. Document changes
4. Deploy to production

---

**All documents are ready to use. Pick your approach and let's build!** 🚀
